package com.example

import com.example.data.model.WorkoutPlanEntity
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun verify_daily_pushup_calculation_increments_by_2() {
    val plan = WorkoutPlanEntity(basePushups = 5, dailyIncrement = 2)
    assertEquals(5, plan.getTargetForDay(1))
    assertEquals(7, plan.getTargetForDay(2))
    assertEquals(9, plan.getTargetForDay(3))
    assertEquals(11, plan.getTargetForDay(4))
    assertEquals(13, plan.getTargetForDay(5))
    assertEquals(15, plan.getTargetForDay(6))
    assertEquals(17, plan.getTargetForDay(7))
    assertEquals(19, plan.getTargetForDay(8))
  }

  @Test
  fun verify_morning_and_evening_session_split_for_30_plus_pushups() {
    val plan = WorkoutPlanEntity(basePushups = 5, dailyIncrement = 2)

    // Below or equal 30: 100% morning
    val (m1, e1) = plan.getSessionTargets(30)
    assertEquals(30, m1)
    assertEquals(0, e1)

    // 32 reps: morning 10 (30%), evening 22 (70%)
    val (m2, e2) = plan.getSessionTargets(32)
    assertEquals(10, m2)
    assertEquals(22, e2)
    assertEquals(32, m2 + e2)

    // 40 reps: morning 12, evening 28
    val (m3, e3) = plan.getSessionTargets(40)
    assertEquals(12, m3)
    assertEquals(28, e3)
    assertEquals(40, m3 + e3)

    // 50 reps: morning 15, evening 35
    val (m5, e5) = plan.getSessionTargets(50)
    assertEquals(15, m5)
    assertEquals(35, e5)
    assertEquals(50, m5 + e5)

    // 100 reps: morning 30, evening 70
    val (m4, e4) = plan.getSessionTargets(100)
    assertEquals(30, m4)
    assertEquals(70, e4)
    assertEquals(100, m4 + e4)
  }
}
