package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

object DateUtils {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val displayDateFormat = SimpleDateFormat("d-MMMM, EEEE", Locale("uz", "UZ"))
    private val shortDisplayDateFormat = SimpleDateFormat("d MMM", Locale("uz", "UZ"))
    private val monthYearFormat = SimpleDateFormat("MMMM yyyy", Locale("uz", "UZ"))
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.US)

    fun getTodayDateString(): String {
        return dateFormat.format(Date())
    }

    fun formatDateString(date: Date): String {
        return dateFormat.format(date)
    }

    fun parseDateString(dateStr: String): Date? {
        return try {
            dateFormat.parse(dateStr)
        } catch (e: Exception) {
            null
        }
    }

    fun formatDisplayDate(dateStr: String): String {
        val parsed = parseDateString(dateStr) ?: return dateStr
        return try {
            displayDateFormat.format(parsed)
        } catch (e: Exception) {
            dateStr
        }
    }

    fun formatShortDisplayDate(dateStr: String): String {
        val parsed = parseDateString(dateStr) ?: return dateStr
        return try {
            shortDisplayDateFormat.format(parsed)
        } catch (e: Exception) {
            dateStr
        }
    }

    fun formatMonthYear(year: Int, monthIndexZeroBased: Int): String {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, monthIndexZeroBased)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        val monthNamesUz = arrayOf(
            "Yanvar", "Fevral", "Mart", "Aprel", "May", "Iyun",
            "Iyul", "Avgust", "Sentabr", "Oktabr", "Noyabr", "Dekabr"
        )
        val m = cal.get(Calendar.MONTH)
        val y = cal.get(Calendar.YEAR)
        return "${monthNamesUz.getOrElse(m) { "" }} $y"
    }

    fun calculateDayIndex(startDateMillis: Long, targetDateStr: String): Int {
        val targetDate = parseDateString(targetDateStr) ?: return 1
        val calStart = Calendar.getInstance().apply {
            timeInMillis = startDateMillis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val calTarget = Calendar.getInstance().apply {
            time = targetDate
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val diffMillis = calTarget.timeInMillis - calStart.timeInMillis
        val diffDays = TimeUnit.MILLISECONDS.toDays(diffMillis).toInt()
        return if (diffDays >= 0) diffDays + 1 else 1
    }

    fun formatTime(hour: Int, minute: Int): String {
        return String.format(Locale.US, "%02d:%02d", hour, minute)
    }
}
