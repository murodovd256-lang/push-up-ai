package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.UiWorkoutState
import com.example.ui.components.CircularPushupProgress
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonButton
import com.example.ui.components.NeonOutlinedButton
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenGlow
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceGlass
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.util.DateUtils

@Composable
fun HomeScreen(
    uiState: UiWorkoutState,
    onStartCameraSession: (sessionType: String) -> Unit,
    onManualAdd: (count: Int, sessionType: String) -> Unit,
    onToggleRestDay: () -> Unit
) {
    var showManualAddDialog by remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()

    val totalTarget = uiState.totalTargetToday
    val completedTotal = uiState.completedTotalToday
    val remaining = maxOf(0, totalTarget - completedTotal)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .verticalScroll(scrollState)
            .padding(horizontal = 18.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "PUSH-UP AI",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Black,
                    color = TextWhite,
                    letterSpacing = 1.sp
                )
                Text(
                    text = DateUtils.formatDisplayDate(uiState.todayDate),
                    fontSize = 13.sp,
                    color = TextMuted,
                    fontWeight = FontWeight.Medium
                )
            }

            Box(
                modifier = Modifier
                    .background(NeonGreenGlow, RoundedCornerShape(14.dp))
                    .border(1.dp, NeonGreen, RoundedCornerShape(14.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "${uiState.currentDayIndex}-KUN",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonGreen
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Paused Banner
        if (uiState.isPaused) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(AccentAmber.copy(alpha = 0.15f), RoundedCornerShape(14.dp))
                    .border(1.dp, AccentAmber, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Pause, contentDescription = null, tint = AccentAmber)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Reja vaqtincha to‘xtatilgan (Sozlamalardan tiklashingiz mumkin)",
                        fontSize = 13.sp,
                        color = AccentAmber,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Rest Day Banner
        if (uiState.isRestDay) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(AccentBlue.copy(alpha = 0.15f), RoundedCornerShape(14.dp))
                    .border(1.dp, AccentBlue, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Bedtime, contentDescription = null, tint = AccentBlue)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Bugun dam olish va tiklanish kuni belgilangan",
                        fontSize = 13.sp,
                        color = AccentBlue,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Main Target Progress Card
        GlassCard(
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Bugungi Kunlik Reja",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )

                Spacer(modifier = Modifier.height(18.dp))

                CircularPushupProgress(
                    completed = completedTotal,
                    target = totalTarget,
                    modifier = Modifier.size(190.dp)
                )

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Bajarildi", fontSize = 12.sp, color = TextMuted)
                        Text(
                            text = "$completedTotal ta",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonGreen
                        )
                    }

                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(34.dp)
                            .background(SurfaceBorder)
                    )

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Qoldi", fontSize = 12.sp, color = TextMuted)
                        Text(
                            text = "$remaining ta",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (remaining == 0) NeonGreen else TextWhite
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Session Distribution (Morning & Evening)
        if (totalTarget > 30) {
            Text(
                text = "KUNLIK TAQSIMOT (30+ ANJIMANIYA)",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextMuted,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Morning Session Card
                val mTarget = uiState.morningTargetToday
                val mCompleted = uiState.completedMorningToday
                val mTimeStr = DateUtils.formatTime(
                    uiState.plan?.morningTimeHour ?: 7,
                    uiState.plan?.morningTimeMinute ?: 0
                )

                GlassCard(
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.WbSunny, contentDescription = null, tint = AccentAmber, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Ertalab (30%)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                        }
                        Text(mTimeStr, fontSize = 11.sp, color = TextMuted)

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "$mCompleted / $mTarget ta",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (mCompleted >= mTarget) NeonGreen else TextWhite
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { if (mTarget > 0) (mCompleted.toFloat() / mTarget).coerceIn(0f, 1f) else 0f },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = NeonGreen,
                            trackColor = SurfaceBorder
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        NeonButton(
                            text = "Boshlash",
                            onClick = { onStartCameraSession("MORNING") },
                            modifier = Modifier.fillMaxWidth().height(42.dp),
                            testTag = "home_start_morning_btn"
                        )
                    }
                }

                // Evening Session Card
                val eTarget = uiState.eveningTargetToday
                val eCompleted = uiState.completedEveningToday
                val eTimeStr = DateUtils.formatTime(
                    uiState.plan?.eveningTimeHour ?: 21,
                    uiState.plan?.eveningTimeMinute ?: 0
                )

                GlassCard(
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.NightsStay, contentDescription = null, tint = AccentBlue, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Kechqurun (70%)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                        }
                        Text(eTimeStr, fontSize = 11.sp, color = TextMuted)

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "$eCompleted / $eTarget ta",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (eCompleted >= eTarget) NeonGreen else TextWhite
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { if (eTarget > 0) (eCompleted.toFloat() / eTarget).coerceIn(0f, 1f) else 0f },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = NeonGreen,
                            trackColor = SurfaceBorder
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        NeonButton(
                            text = "Boshlash",
                            onClick = { onStartCameraSession("EVENING") },
                            modifier = Modifier.fillMaxWidth().height(42.dp),
                            testTag = "home_start_evening_btn"
                        )
                    }
                }
            }
        } else {
            // Single Session (<= 30 reps)
            val timeStr = DateUtils.formatTime(
                uiState.plan?.morningTimeHour ?: 7,
                uiState.plan?.morningTimeMinute ?: 0
            )
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.WbSunny, contentDescription = null, tint = AccentAmber, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Ertalabki mashg‘ulot", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Vaqt: $timeStr  •  Barcha $totalTarget ta ertalab bajariladi", fontSize = 12.sp, color = TextMuted)
                    }
                    if (completedTotal >= totalTarget) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(32.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Main Camera Workout Start Button
        NeonButton(
            text = "AI KAMERA BILAN BOSHLASH",
            icon = Icons.Default.Videocam,
            onClick = { onStartCameraSession("GENERAL") },
            modifier = Modifier.fillMaxWidth(),
            testTag = "home_start_camera_main_btn"
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Secondary Actions Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            NeonOutlinedButton(
                text = "Qo‘lda qo‘shish",
                icon = Icons.Default.Edit,
                onClick = { showManualAddDialog = true },
                modifier = Modifier.weight(1f),
                testTag = "home_manual_add_btn"
            )

            NeonOutlinedButton(
                text = if (uiState.isRestDay) "Tiklash" else "Dam olish",
                icon = Icons.Default.Bedtime,
                onClick = onToggleRestDay,
                borderColor = if (uiState.isRestDay) AccentBlue else SurfaceBorder,
                modifier = Modifier.weight(1f),
                testTag = "home_rest_day_btn"
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
    }

    // Manual Add Dialog
    if (showManualAddDialog) {
        var repsToAdd by remember { mutableIntStateOf(5) }
        var selectedSession by remember { mutableStateOf("MORNING") }

        AlertDialog(
            onDismissRequest = { showManualAddDialog = false },
            containerColor = SurfaceDark,
            title = {
                Text("Qo‘lda anjimaniya qo‘shish", color = TextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Kamera ishlatmasdan yoki xatolik bo‘lganda qo‘lda natija kiriting:",
                        fontSize = 13.sp,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        IconButton(
                            onClick = { if (repsToAdd > 1) repsToAdd-- },
                            modifier = Modifier.background(SurfaceCard, CircleShape)
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = null, tint = TextWhite)
                        }

                        Text(
                            text = "$repsToAdd ta",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonGreen,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )

                        IconButton(
                            onClick = { repsToAdd++ },
                            modifier = Modifier.background(SurfaceCard, CircleShape)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = TextWhite)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(1, 5, 10, 15, 20).forEach { p ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (repsToAdd == p) NeonGreen else SurfaceCard)
                                    .clickable { repsToAdd = p }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "+$p",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (repsToAdd == p) BackgroundDark else TextWhite
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onManualAdd(repsToAdd, selectedSession)
                        showManualAddDialog = false
                    }
                ) {
                    Text("Qo‘shish", color = NeonGreen, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showManualAddDialog = false }) {
                    Text("Bekor qilish", color = TextMuted)
                }
            }
        )
    }
}
