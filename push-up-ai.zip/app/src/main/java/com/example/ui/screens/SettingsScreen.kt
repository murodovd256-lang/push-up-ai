package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.UiWorkoutState
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonButton
import com.example.ui.components.NeonOutlinedButton
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentRed
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenHover
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.util.DateUtils
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    uiState: UiWorkoutState,
    onUpdateTimes: (mHour: Int, mMin: Int, eHour: Int, eMin: Int) -> Unit,
    onUpdateBaseAndIncrement: (base: Int, increment: Int) -> Unit,
    onTogglePause: () -> Unit,
    onToggleNotifications: (Boolean) -> Unit,
    onTestNotification: (isMorning: Boolean) -> Unit,
    onResetAllData: () -> Unit,
    onExportData: suspend () -> String,
    onImportData: suspend (String) -> Boolean
) {
    val plan = uiState.plan
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    var showMorningPicker by remember { mutableStateOf(false) }
    var showEveningPicker by remember { mutableStateOf(false) }
    var showResetConfirmDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    var exportedJsonText by remember { mutableStateOf("") }
    var showImportDialog by remember { mutableStateOf(false) }
    var importJsonText by remember { mutableStateOf("") }

    val morningH = plan?.morningTimeHour ?: 7
    val morningM = plan?.morningTimeMinute ?: 0
    val eveningH = plan?.eveningTimeHour ?: 21
    val eveningM = plan?.eveningTimeMinute ?: 0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .verticalScroll(scrollState)
            .padding(horizontal = 18.dp, vertical = 20.dp)
    ) {
        // Title
        Text(
            text = "SOZLAMALAR",
            fontSize = 22.sp,
            fontWeight = FontWeight.Black,
            color = TextWhite,
            letterSpacing = 1.sp
        )
        Text(
            text = "Mashq jadvali va ilova parametrlari",
            fontSize = 13.sp,
            color = TextMuted,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // 1. Workout Times Section
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Schedule, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Mashg‘ulot Vaqtlari", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Morning
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(SurfaceCard)
                            .border(1.dp, SurfaceBorder, RoundedCornerShape(12.dp))
                            .clickable { showMorningPicker = true }
                            .padding(14.dp)
                    ) {
                        Column {
                            Text("Ertalabki vaqt", fontSize = 12.sp, color = TextMuted)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = DateUtils.formatTime(morningH, morningM),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeonGreen
                            )
                        }
                    }

                    // Evening
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(SurfaceCard)
                            .border(1.dp, SurfaceBorder, RoundedCornerShape(12.dp))
                            .clickable { showEveningPicker = true }
                            .padding(14.dp)
                    ) {
                        Column {
                            Text("Kechki vaqt", fontSize = 12.sp, color = TextMuted)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = DateUtils.formatTime(eveningH, eveningM),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeonGreen
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 2. Increments & Targets Section
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.TrendingUp, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Kunlik Oshish Miqdori", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                }

                Text(
                    text = "Har kuni reja nechta anjimaniyaga oshishi kerak",
                    fontSize = 12.sp,
                    color = TextMuted,
                    modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val currentInc = plan?.dailyIncrement ?: 2
                    val currentBase = plan?.basePushups ?: 5

                    listOf(1, 2, 3, 5).forEach { inc ->
                        val isSelected = currentInc == inc
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) NeonGreen else SurfaceCard)
                                .border(1.dp, if (isSelected) NeonGreen else SurfaceBorder, RoundedCornerShape(10.dp))
                                .clickable {
                                    onUpdateBaseAndIncrement(currentBase, inc)
                                }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "+$inc",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) BackgroundDark else TextWhite
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 3. Pause & Vacation Mode
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Mashg‘ulotlarni To‘xtatish (Pauza)",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                        Text(
                            text = "Vaqtinchalik safar yoki charchoqda eslatmalar to‘xtatiladi",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                    }

                    Switch(
                        checked = plan?.isPaused == true,
                        onCheckedChange = { onTogglePause() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = BackgroundDark,
                            checkedTrackColor = AccentAmber,
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = SurfaceBorder
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 4. Notifications Section
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Eslatma Bildirishnomalari",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                        Text(
                            text = "Ertalab va kechqurun belgilangan vaqtda bildirishnoma",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                    }

                    Switch(
                        checked = plan?.notificationsEnabled == true,
                        onCheckedChange = { onToggleNotifications(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = BackgroundDark,
                            checkedTrackColor = NeonGreen,
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = SurfaceBorder
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                NeonOutlinedButton(
                    text = "Bildirishnomani Sinash 🔔",
                    onClick = {
                        onTestNotification(true)
                        Toast.makeText(context, "Eslatma yuborildi!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 5. Data Backup & Restore
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "Ma'lumotlar Zaxirasi",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    NeonOutlinedButton(
                        text = "Eksport",
                        icon = Icons.Default.Download,
                        onClick = {
                            coroutineScope.launch {
                                exportedJsonText = onExportData()
                                showExportDialog = true
                            }
                        },
                        modifier = Modifier.weight(1f)
                    )

                    NeonOutlinedButton(
                        text = "Tiklash",
                        icon = Icons.Default.Upload,
                        onClick = { showImportDialog = true },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 6. Reset All to Zero (Requirement 1)
        NeonOutlinedButton(
            text = "Noldan Qayta Boshlash (Hammasini tozalash)",
            icon = Icons.Default.DeleteForever,
            borderColor = AccentRed,
            onClick = { showResetConfirmDialog = true },
            modifier = Modifier.fillMaxWidth(),
            testTag = "settings_reset_all_btn"
        )

        Spacer(modifier = Modifier.height(24.dp))
    }

    // Time Pickers
    if (showMorningPicker) {
        TimePickerSimpleDialog(
            title = "Ertalabki mashg‘ulot vaqti",
            currentHour = morningH,
            currentMinute = morningM,
            onDismiss = { showMorningPicker = false },
            onConfirm = { h, m ->
                onUpdateTimes(h, m, eveningH, eveningM)
                showMorningPicker = false
            }
        )
    }

    if (showEveningPicker) {
        TimePickerSimpleDialog(
            title = "Kechki mashg‘ulot vaqti",
            currentHour = eveningH,
            currentMinute = eveningM,
            onDismiss = { showEveningPicker = false },
            onConfirm = { h, m ->
                onUpdateTimes(morningH, morningM, h, m)
                showEveningPicker = false
            }
        )
    }

    // Reset Confirm Dialog
    if (showResetConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showResetConfirmDialog = false },
            containerColor = SurfaceDark,
            title = {
                Text("Barcha ma'lumotlarni o‘chirish?", color = AccentRed, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    text = "Barcha kiritilgan mashqlar, kalendar tarixi va rejalar butunlay o‘chiriladi va 0 dan boshlanadi.",
                    fontSize = 14.sp,
                    color = TextWhite
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showResetConfirmDialog = false
                        onResetAllData()
                        Toast.makeText(context, "Barcha ma'lumotlar noldan tozalandi", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Text("Ha, hammasini tozalash", color = AccentRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirmDialog = false }) {
                    Text("Bekor qilish", color = TextMuted)
                }
            }
        )
    }

    // Export Dialog
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            containerColor = SurfaceDark,
            title = {
                Text("Ma'lumotlar Eksporti (JSON)", color = TextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text("Ushbu JSON matnini nusxa olib saqlab qo‘yishingiz mumkin:", fontSize = 13.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SurfaceCard, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text(exportedJsonText, fontSize = 11.sp, color = NeonGreen)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        clipboardManager.setText(AnnotatedString(exportedJsonText))
                        Toast.makeText(context, "Nusxa olindi!", Toast.LENGTH_SHORT).show()
                        showExportDialog = false
                    }
                ) {
                    Text("Nusxa olish", color = NeonGreen, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) {
                    Text("Yopish", color = TextMuted)
                }
            }
        )
    }

    // Import Dialog
    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            containerColor = SurfaceDark,
            title = {
                Text("Ma'lumotlarni Tiklash", color = TextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text("Oldin eksport qilingan JSON matnini kiriting:", fontSize = 13.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = importJsonText,
                        onValueChange = { importJsonText = it },
                        modifier = Modifier.fillMaxWidth().height(140.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonGreen,
                            unfocusedBorderColor = SurfaceBorder,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        )
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        coroutineScope.launch {
                            val success = onImportData(importJsonText)
                            if (success) {
                                Toast.makeText(context, "Ma'lumotlar tiklandi!", Toast.LENGTH_SHORT).show()
                                showImportDialog = false
                            } else {
                                Toast.makeText(context, "Noto‘g‘ri JSON formati!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                ) {
                    Text("Tiklash", color = NeonGreen, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text("Bekor qilish", color = TextMuted)
                }
            }
        )
    }
}
