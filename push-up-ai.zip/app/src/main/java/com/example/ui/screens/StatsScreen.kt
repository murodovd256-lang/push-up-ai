package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DailyWorkoutEntity
import com.example.ui.UiWorkoutState
import com.example.ui.components.GlassCard
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenGlow
import com.example.ui.theme.NeonGreenHover
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.util.DateUtils
import java.util.Calendar

@Composable
fun StatsScreen(uiState: UiWorkoutState) {
    val workouts = uiState.allWorkouts
    val scrollState = rememberScrollState()

    // 1. Calculations from real workout data
    val totalPushupsAllTime = workouts.sumOf { it.completedTotal }
    val maxDailyRecord = workouts.maxOfOrNull { it.completedTotal } ?: 0
    val totalMorning = workouts.sumOf { it.completedMorning }
    val totalEvening = workouts.sumOf { it.completedEvening }

    // Consecutive streak
    val streak = calculateStreak(workouts)

    // Last 7 days total
    val last7DaysWorkouts = workouts.takeLast(7)
    val weeklyTotal = last7DaysWorkouts.sumOf { it.completedTotal }

    // Last 30 days total
    val monthlyTotal = workouts.takeLast(30).sumOf { it.completedTotal }

    // Completion rate
    val completedDaysCount = workouts.count { it.isCompleted || (it.completedTotal >= it.targetCount && it.completedTotal > 0) }
    val activeDaysCount = maxOf(1, workouts.size)
    val completionRate = (completedDaysCount * 100) / activeDaysCount

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .verticalScroll(scrollState)
            .padding(horizontal = 18.dp, vertical = 20.dp)
    ) {
        // Title
        Text(
            text = "HISOBOT VA STATISTIKA",
            fontSize = 22.sp,
            fontWeight = FontWeight.Black,
            color = TextWhite,
            letterSpacing = 1.sp
        )
        Text(
            text = "Haqiqiy bajarilgan mashqlar asosidagi tahlil",
            fontSize = 13.sp,
            color = TextMuted,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // KPI Top Grid (2x2)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            KpiStatCard(
                title = "Jami Anjimaniya",
                value = "$totalPushupsAllTime",
                subtext = "Barcha vaqt davomida",
                icon = Icons.Default.FitnessCenter,
                iconTint = NeonGreen,
                modifier = Modifier.weight(1f)
            )

            KpiStatCard(
                title = "Ketma-ket Kunlar",
                value = "$streak kun",
                subtext = if (streak > 0) "A'lo natija! 🔥" else "Bugun boshlang",
                icon = Icons.Default.LocalFireDepartment,
                iconTint = AccentAmber,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            KpiStatCard(
                title = "Eng Yuqori Rekord",
                value = "$maxDailyRecord ta",
                subtext = "Bir kunda eng ko‘p",
                icon = Icons.Default.EmojiEvents,
                iconTint = AccentAmber,
                modifier = Modifier.weight(1f)
            )

            KpiStatCard(
                title = "Reja Bajarilishi",
                value = "$completionRate%",
                subtext = "$completedDaysCount / $activeDaysCount kun to‘liq",
                icon = Icons.Default.Timeline,
                iconTint = NeonGreenHover,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Progress Chart Card
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Rivojlanish Grafigi",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                    Text(
                        text = "Oxirgi kunlar",
                        fontSize = 12.sp,
                        color = NeonGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Custom Canvas Chart
                PushupProgressChart(
                    data = last7DaysWorkouts,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(170.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Weekly & Monthly Summary Card
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "Davriy Natijalar",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Today
                StatProgressRow(
                    label = "Bugun",
                    value = "${uiState.completedTotalToday} / ${uiState.totalTargetToday} ta",
                    progress = if (uiState.totalTargetToday > 0) (uiState.completedTotalToday.toFloat() / uiState.totalTargetToday).coerceIn(0f, 1f) else 0f
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Weekly
                StatProgressRow(
                    label = "Haftalik natija",
                    value = "$weeklyTotal ta",
                    progress = if (weeklyTotal > 0) 0.85f else 0.05f
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Monthly
                StatProgressRow(
                    label = "Oylik natija",
                    value = "$monthlyTotal ta",
                    progress = if (monthlyTotal > 0) 0.95f else 0.05f
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Morning vs Evening Breakdown Card
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "Ertalab vs Kechqurun Taqsimoti",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.WbSunny, contentDescription = null, tint = AccentAmber, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Ertalab: $totalMorning ta", fontSize = 13.sp, color = TextWhite)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.NightsStay, contentDescription = null, tint = AccentBlue, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Kechqurun: $totalEvening ta", fontSize = 13.sp, color = TextWhite)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                val totalSessionsSum = maxOf(1, totalMorning + totalEvening)
                val morningFraction = totalMorning.toFloat() / totalSessionsSum

                LinearProgressIndicator(
                    progress = { morningFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = AccentAmber,
                    trackColor = AccentBlue
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun KpiStatCard(
    title: String,
    value: String,
    subtext: String,
    icon: ImageVector,
    iconTint: Color,
    modifier: Modifier = Modifier
) {
    GlassCard(modifier = modifier) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextMuted
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = value,
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                color = TextWhite
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = subtext,
                fontSize = 11.sp,
                color = TextMuted
            )
        }
    }
}

@Composable
fun StatProgressRow(
    label: String,
    value: String,
    progress: Float
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontSize = 13.sp, color = TextMuted)
            Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextWhite)
        }
        Spacer(modifier = Modifier.height(6.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = NeonGreen,
            trackColor = SurfaceBorder
        )
    }
}

@Composable
fun PushupProgressChart(
    data: List<DailyWorkoutEntity>,
    modifier: Modifier = Modifier
) {
    if (data.isEmpty()) {
        Box(
            modifier = modifier,
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Hali mashqlar bajarilmagan",
                fontSize = 13.sp,
                color = TextMuted
            )
        }
        return
    }

    val maxVal = maxOf(10, data.maxOfOrNull { maxOf(it.targetCount, it.completedTotal) } ?: 10)

    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height - 30.dp.toPx() // leave room for labels
        val stepX = width / data.size
        val barWidth = (stepX * 0.45f).coerceAtMost(28.dp.toPx())

        // Draw horizontal grid lines
        for (i in 1..3) {
            val y = height * (1f - i / 3f)
            drawLine(
                color = SurfaceBorder.copy(alpha = 0.5f),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1.dp.toPx()
            )
        }

        // Draw bars and targets
        data.forEachIndexed { index, item ->
            val centerX = index * stepX + stepX / 2f
            val targetHeight = (item.targetCount.toFloat() / maxVal) * height
            val completedHeight = (item.completedTotal.toFloat() / maxVal) * height

            // Target dashed/faint bar
            drawRoundRect(
                color = SurfaceBorder,
                topLeft = Offset(centerX - barWidth / 2f, height - targetHeight),
                size = Size(barWidth, targetHeight),
                cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
            )

            // Completed glowing bar
            if (completedHeight > 0) {
                drawRoundRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(NeonGreenHover, NeonGreen)
                    ),
                    topLeft = Offset(centerX - barWidth / 2f, height - completedHeight),
                    size = Size(barWidth, completedHeight),
                    cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                )
            }
        }
    }
}

private fun calculateStreak(workouts: List<DailyWorkoutEntity>): Int {
    if (workouts.isEmpty()) return 0
    var streak = 0
    val sorted = workouts.sortedByDescending { it.date }
    for (w in sorted) {
        if (w.isCompleted || (w.completedTotal >= w.targetCount && w.completedTotal > 0)) {
            streak++
        } else if (w.isRestDay) {
            // Rest days don't break streak
            continue
        } else {
            break
        }
    }
    return streak
}
