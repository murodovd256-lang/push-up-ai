package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.SystemClock
import android.util.Size
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.camera.PushupPoseAnalysisResult
import com.example.camera.PushupPoseAnalyzer
import com.example.ui.UiWorkoutState
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonButton
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentRed
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenGlow
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.google.mlkit.vision.pose.PoseLandmark
import java.util.concurrent.Executors

@Composable
fun CameraScreen(
    uiState: UiWorkoutState,
    onPoseUpdated: (PushupPoseAnalysisResult) -> Unit,
    onRepCompleted: (Int) -> Unit,
    onAdjustManualCount: (delta: Int) -> Unit,
    onFinishSession: (accuracyScore: Int) -> Unit,
    onCancelSession: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { granted ->
            hasCameraPermission = granted
        }
    )

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Intercept back button to safely shut down camera
    BackHandler {
        onCancelSession()
    }

    var cameraSelector by remember {
        mutableStateOf(CameraSelector.DEFAULT_FRONT_CAMERA)
    }

    val currentReps = uiState.cameraSessionReps
    val targetReps = uiState.cameraSessionTarget
    val remainingReps = maxOf(0, targetReps - currentReps)
    val latestPose = uiState.latestPoseResult

    var showFinishDialog by remember { mutableStateOf(false) }

    // Camera Executor
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    val analyzer = remember {
        PushupPoseAnalyzer(
            onResult = { result ->
                onPoseUpdated(result)
            },
            onRepCompleted = { count ->
                onRepCompleted(count)
            }
        ).apply {
            resetCount(uiState.cameraSessionReps)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        if (hasCameraPermission) {
            // Camera Preview View
            AndroidView(
                factory = { ctx ->
                    val previewView = PreviewView(ctx).apply {
                        implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                    }

                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    cameraProviderFuture.addListener({
                        val cameraProvider = cameraProviderFuture.get()

                        val preview = Preview.Builder().build().also {
                            it.surfaceProvider = previewView.surfaceProvider
                        }

                        val imageAnalysis = ImageAnalysis.Builder()
                            .setTargetResolution(Size(640, 480))
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()
                            .also {
                                it.setAnalyzer(cameraExecutor, analyzer)
                            }

                        try {
                            cameraProvider.unbindAll()
                            cameraProvider.bindToLifecycle(
                                lifecycleOwner,
                                cameraSelector,
                                preview,
                                imageAnalysis
                            )
                        } catch (e: Exception) {
                            // Camera binding exception
                        }
                    }, ContextCompat.getMainExecutor(ctx))

                    previewView
                },
                modifier = Modifier.fillMaxSize(),
                update = { previewView ->
                    // Rebind on cameraSelector change
                    val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
                    cameraProviderFuture.addListener({
                        val cameraProvider = cameraProviderFuture.get()
                        val preview = Preview.Builder().build().also {
                            it.surfaceProvider = previewView.surfaceProvider
                        }
                        val imageAnalysis = ImageAnalysis.Builder()
                            .setTargetResolution(Size(640, 480))
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()
                            .also {
                                it.setAnalyzer(cameraExecutor, analyzer)
                            }

                        try {
                            cameraProvider.unbindAll()
                            cameraProvider.bindToLifecycle(
                                lifecycleOwner,
                                cameraSelector,
                                preview,
                                imageAnalysis
                            )
                        } catch (e: Exception) {
                            // Fallback
                        }
                    }, ContextCompat.getMainExecutor(context))
                }
            )

            // Real-time Skeleton Overlay
            if (latestPose != null && latestPose.isBodyDetected) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val canvasWidth = size.width
                    val canvasHeight = size.height

                    val imgW = if (latestPose.rotationDegrees == 90 || latestPose.rotationDegrees == 270) {
                        latestPose.imageHeight.toFloat()
                    } else {
                        latestPose.imageWidth.toFloat()
                    }
                    val imgH = if (latestPose.rotationDegrees == 90 || latestPose.rotationDegrees == 270) {
                        latestPose.imageWidth.toFloat()
                    } else {
                        latestPose.imageHeight.toFloat()
                    }

                    val scaleX = if (imgW > 0) canvasWidth / imgW else 1f
                    val scaleY = if (imgH > 0) canvasHeight / imgH else 1f

                    val isFrontCam = cameraSelector == CameraSelector.DEFAULT_FRONT_CAMERA

                    fun mapPoint(type: Int): Offset? {
                        val pt = latestPose.landmarks[type] ?: return null
                        if (pt.likelihood < 0.45f) return null

                        var mappedX = pt.x * scaleX
                        val mappedY = pt.y * scaleY

                        // Mirror x coordinate for front camera
                        if (isFrontCam) {
                            mappedX = canvasWidth - mappedX
                        }

                        return Offset(mappedX, mappedY)
                    }

                    // Bone connections
                    val connections = listOf(
                        PoseLandmark.LEFT_SHOULDER to PoseLandmark.RIGHT_SHOULDER,
                        PoseLandmark.LEFT_SHOULDER to PoseLandmark.LEFT_ELBOW,
                        PoseLandmark.LEFT_ELBOW to PoseLandmark.LEFT_WRIST,
                        PoseLandmark.RIGHT_SHOULDER to PoseLandmark.RIGHT_ELBOW,
                        PoseLandmark.RIGHT_ELBOW to PoseLandmark.RIGHT_WRIST,
                        PoseLandmark.LEFT_SHOULDER to PoseLandmark.LEFT_HIP,
                        PoseLandmark.RIGHT_SHOULDER to PoseLandmark.RIGHT_HIP,
                        PoseLandmark.LEFT_HIP to PoseLandmark.RIGHT_HIP,
                        PoseLandmark.LEFT_HIP to PoseLandmark.LEFT_KNEE,
                        PoseLandmark.RIGHT_HIP to PoseLandmark.RIGHT_KNEE
                    )

                    // Draw bones
                    for ((start, end) in connections) {
                        val p1 = mapPoint(start)
                        val p2 = mapPoint(end)
                        if (p1 != null && p2 != null) {
                            drawLine(
                                color = NeonGreen.copy(alpha = 0.85f),
                                start = p1,
                                end = p2,
                                strokeWidth = 5.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        }
                    }

                    // Draw joints
                    latestPose.landmarks.forEach { (type, pt) ->
                        if (pt.likelihood >= 0.45f) {
                            val p = mapPoint(type)
                            if (p != null) {
                                drawCircle(
                                    color = Color.White,
                                    radius = 6.dp.toPx(),
                                    center = p
                                )
                                drawCircle(
                                    color = NeonGreen,
                                    radius = 9.dp.toPx(),
                                    center = p,
                                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
                                )
                            }
                        }
                    }
                }
            }

            // Cleanup when leaving screen
            DisposableEffect(Unit) {
                onDispose {
                    try {
                        val cameraProvider = ProcessCameraProvider.getInstance(context).get()
                        cameraProvider.unbindAll()
                    } catch (e: Exception) {
                        // Safe unbind
                    }
                    cameraExecutor.shutdown()
                }
            }
        } else {
            // Permission missing fallback
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = AccentAmber,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Kamera ruxsati zarur",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "AI anjimaniyalarni avtomatik sanashi uchun kamera ruxsati talab qilinadi. Kamera tasvirlari serverga yuborilmaydi.",
                    fontSize = 14.sp,
                    color = TextMuted,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
                NeonButton(
                    text = "Ruxsat berish",
                    onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Top Navigation Bar Overlay
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 40.dp, start = 16.dp, end = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onCancelSession,
                modifier = Modifier
                    .background(SurfaceDark.copy(alpha = 0.75f), CircleShape)
                    .border(1.dp, SurfaceBorder, CircleShape)
                    .testTag("camera_back_btn")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Chiqish", tint = TextWhite)
            }

            // Session Badge
            Box(
                modifier = Modifier
                    .background(SurfaceDark.copy(alpha = 0.8f), RoundedCornerShape(12.dp))
                    .border(1.dp, NeonGreen, RoundedCornerShape(12.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "AI SANAGICH  •  ${uiState.cameraSessionType}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonGreen
                )
            }

            // Switch Camera Button
            IconButton(
                onClick = {
                    cameraSelector = if (cameraSelector == CameraSelector.DEFAULT_FRONT_CAMERA) {
                        CameraSelector.DEFAULT_BACK_CAMERA
                    } else {
                        CameraSelector.DEFAULT_FRONT_CAMERA
                    }
                },
                modifier = Modifier
                    .background(SurfaceDark.copy(alpha = 0.75f), CircleShape)
                    .border(1.dp, SurfaceBorder, CircleShape)
                    .testTag("camera_switch_btn")
            ) {
                Icon(Icons.Default.Cameraswitch, contentDescription = "Kamerani almashtirish", tint = TextWhite)
            }
        }

        // Bottom HUD Overlay
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        ) {
            // Live AI Guidance Pill
            val feedbackText = latestPose?.formFeedback ?: "Kamerani o‘zingizga qaratib qo‘ying"
            val isBodyFound = latestPose?.isBodyDetected == true

            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = SurfaceDark.copy(alpha = 0.90f),
                borderColor = if (isBodyFound) NeonGreen else AccentAmber
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(if (isBodyFound) NeonGreen else AccentAmber, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = feedbackText,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isBodyFound) TextWhite else AccentAmber,
                        modifier = Modifier.weight(1f)
                    )
                    if (latestPose != null && latestPose.currentElbowAngle < 179) {
                        Text(
                            text = "${latestPose.currentElbowAngle.toInt()}°",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonGreen
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Massive Rep Counter Card
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = SurfaceDark.copy(alpha = 0.92f)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Manual Minus Button
                        IconButton(
                            onClick = {
                                analyzer.adjustRepCount(-1)
                                onAdjustManualCount(-1)
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .background(SurfaceCard, CircleShape)
                                .border(1.dp, SurfaceBorder, CircleShape)
                                .testTag("camera_manual_minus")
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "-1", tint = TextWhite)
                        }

                        // Big Live Reps Display
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = "$currentReps",
                                    fontSize = 48.sp,
                                    fontWeight = FontWeight.Black,
                                    color = NeonGreen
                                )
                                Text(
                                    text = " / $targetReps",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextMuted,
                                    modifier = Modifier.padding(bottom = 8.dp)
                                )
                            }
                            Text(
                                text = "Qolgan: $remainingReps ta",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (remainingReps == 0) NeonGreen else TextWhite
                            )
                        }

                        // Manual Plus Button
                        IconButton(
                            onClick = {
                                analyzer.adjustRepCount(1)
                                onAdjustManualCount(1)
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .background(SurfaceCard, CircleShape)
                                .border(1.dp, SurfaceBorder, CircleShape)
                                .testTag("camera_manual_plus")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "+1", tint = TextWhite)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Progress bar
                    LinearProgressIndicator(
                        progress = { if (targetReps > 0) (currentReps.toFloat() / targetReps).coerceIn(0f, 1f) else 0f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = NeonGreen,
                        trackColor = SurfaceBorder
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Finish Workout Button
                    NeonButton(
                        text = "MASHG‘ULOTNI YAKUNLASH",
                        icon = Icons.Default.Check,
                        onClick = { showFinishDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "camera_finish_workout_btn"
                    )
                }
            }
        }
    }

    // Finish Workout Confirmation Dialog
    if (showFinishDialog) {
        AlertDialog(
            onDismissRequest = { showFinishDialog = false },
            containerColor = SurfaceDark,
            title = {
                Text(
                    text = "Mashg‘ulotni yakunlash",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )
            },
            text = {
                Column {
                    Text(
                        text = "Siz $currentReps ta to‘liq anjimaniya bajardingiz!",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NeonGreen
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Natija hisobotlaringizga saqlanadi va kamera o‘chiriladi.",
                        fontSize = 13.sp,
                        color = TextMuted
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showFinishDialog = false
                        onFinishSession(latestPose?.formAccuracyScore ?: 95)
                    }
                ) {
                    Text("Saqlash va Chiqish", color = NeonGreen, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showFinishDialog = false }) {
                    Text("Davom ettirish", color = TextMuted)
                }
            }
        )
    }
}
