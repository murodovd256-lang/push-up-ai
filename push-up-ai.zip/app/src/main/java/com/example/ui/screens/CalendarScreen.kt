package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DailyWorkoutEntity
import com.example.ui.UiWorkoutState
import com.example.ui.components.GlassCard
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenGlow
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceGlass
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.util.DateUtils
import java.util.Calendar
import java.util.Locale

@Composable
fun CalendarScreen(
    uiState: UiWorkoutState,
    onSelectDate: (String) -> Unit,
    onManualUpdateDayCount: (date: String, newTotal: Int) -> Unit
) {
    val plan = uiState.plan
    val todayStr = DateUtils.getTodayDateString()

    var currentCalendarMonth by remember {
        val cal = Calendar.getInstance()
        mutableStateOf(cal)
    }

    var selectedDayDetail by remember {
        mutableStateOf<DailyWorkoutEntity?>(null)
    }
    var showDetailDialog by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf(false) }

    val year = currentCalendarMonth.get(Calendar.YEAR)
    val month = currentCalendarMonth.get(Calendar.MONTH)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 18.dp, vertical = 20.dp)
    ) {
        // Title
        Text(
            text = "MASHQLAR KALENDARI",
            fontSize = 22.sp,
            fontWeight = FontWeight.Black,
            color = TextWhite,
            letterSpacing = 1.sp
        )
        Text(
            text = "Har bir kunlik reja va natijalarni kuzating",
            fontSize = 13.sp,
            color = TextMuted,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Month Navigation Header
        GlassCard(
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        val newCal = Calendar.getInstance().apply {
                            time = currentCalendarMonth.time
                            add(Calendar.MONTH, -1)
                        }
                        currentCalendarMonth = newCal
                    },
                    modifier = Modifier.testTag("cal_prev_month")
                ) {
                    Icon(Icons.Default.ChevronLeft, contentDescription = "Oldingi oy", tint = TextWhite)
                }

                Text(
                    text = DateUtils.formatMonthYear(year, month),
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonGreen
                )

                IconButton(
                    onClick = {
                        val newCal = Calendar.getInstance().apply {
                            time = currentCalendarMonth.time
                            add(Calendar.MONTH, 1)
                        }
                        currentCalendarMonth = newCal
                    },
                    modifier = Modifier.testTag("cal_next_month")
                ) {
                    Icon(Icons.Default.ChevronRight, contentDescription = "Keyingi oy", tint = TextWhite)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Weekday names
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            val weekDays = listOf("Dsh", "Ssh", "Chr", "Pay", "Jum", "Shn", "Yak")
            weekDays.forEach { day ->
                Text(
                    text = day,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMuted,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Month Grid Calculation
        val firstDayOfMonthCal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        val daysInMonth = firstDayOfMonthCal.getActualMaximum(Calendar.DAY_OF_MONTH)
        // In Java Calendar, Sunday is 1, Monday is 2 ... Saturday is 7
        // Let's convert Monday to 0 ... Sunday to 6
        val firstDayOfWeek = (firstDayOfMonthCal.get(Calendar.DAY_OF_WEEK) + 5) % 7
        val totalCells = firstDayOfWeek + daysInMonth

        LazyVerticalGrid(
            columns = GridCells.Fixed(7),
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Empty offset slots
            items(firstDayOfWeek) {
                Box(modifier = Modifier.aspectRatio(1f))
            }

            // Month day slots
            items(daysInMonth) { index ->
                val dayNumber = index + 1
                val dateString = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayNumber)

                val dayWorkout = uiState.allWorkouts.find { it.date == dateString }
                val isToday = dateString == todayStr

                // Calculate plan day target
                val planDayIndex = if (plan != null) DateUtils.calculateDayIndex(plan.startDateMillis, dateString) else 1
                val calculatedTarget = plan?.getTargetForDay(planDayIndex) ?: 5
                val targetToDisplay = dayWorkout?.targetCount ?: calculatedTarget

                // Cell styling
                val isCompleted = dayWorkout?.isCompleted == true || (dayWorkout != null && dayWorkout.completedTotal >= dayWorkout.targetCount && dayWorkout.completedTotal > 0)
                val isRestDay = dayWorkout?.isRestDay == true
                val hasStarted = plan != null && plan.startDateMillis <= (DateUtils.parseDateString(dateString)?.time ?: 0L) + 86400000L

                val borderColor = when {
                    isCompleted -> NeonGreen
                    isRestDay -> AccentBlue
                    isToday -> NeonGreen
                    dayWorkout != null && dayWorkout.completedTotal > 0 -> AccentAmber
                    else -> SurfaceBorder
                }

                val backgroundColor = when {
                    isCompleted -> NeonGreenGlow
                    isRestDay -> AccentBlue.copy(alpha = 0.2f)
                    isToday -> SurfaceCard
                    else -> SurfaceDark
                }

                Box(
                    modifier = Modifier
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(backgroundColor)
                        .border(if (isToday) 2.dp else 1.dp, borderColor, RoundedCornerShape(12.dp))
                        .clickable {
                            val detail = dayWorkout ?: DailyWorkoutEntity(
                                date = dateString,
                                dayNumber = planDayIndex,
                                targetCount = targetToDisplay,
                                completedTotal = 0,
                                completedMorning = 0,
                                completedEvening = 0,
                                isRestDay = false,
                                isCompleted = false
                            )
                            selectedDayDetail = detail
                            showDetailDialog = true
                        }
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "$dayNumber",
                            fontSize = 13.sp,
                            fontWeight = if (isToday) FontWeight.Black else FontWeight.Bold,
                            color = if (isCompleted) NeonGreen else TextWhite
                        )
                        if (hasStarted) {
                            Text(
                                text = if (dayWorkout != null && dayWorkout.completedTotal > 0) "${dayWorkout.completedTotal}" else "$targetToDisplay",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isCompleted) NeonGreen else (if (dayWorkout != null && dayWorkout.completedTotal > 0) AccentAmber else TextMuted)
                            )
                        }
                    }
                }
            }
        }

        // Legend / Indicator Row
        GlassCard(
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp).background(NeonGreen, CircleShape))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Bajarildi", fontSize = 11.sp, color = TextWhite)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp).background(AccentAmber, CircleShape))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Qisman", fontSize = 11.sp, color = TextWhite)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp).background(AccentBlue, CircleShape))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Dam olish", fontSize = 11.sp, color = TextWhite)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp).border(1.dp, SurfaceBorder, CircleShape))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Rejalashtirilgan", fontSize = 11.sp, color = TextMuted)
                }
            }
        }
    }

    // Day Detail Dialog
    if (showDetailDialog && selectedDayDetail != null) {
        val detail = selectedDayDetail!!
        val isDone = detail.isCompleted || detail.completedTotal >= detail.targetCount && detail.completedTotal > 0
        val (mTarget, eTarget) = plan?.getSessionTargets(detail.targetCount) ?: Pair(detail.targetCount, 0)

        AlertDialog(
            onDismissRequest = { showDetailDialog = false },
            containerColor = SurfaceDark,
            title = {
                Text(
                    text = DateUtils.formatDisplayDate(detail.date),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )
            },
            text = {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Kun raqami:", fontSize = 14.sp, color = TextMuted)
                        Text("${detail.dayNumber}-kun", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NeonGreen)
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Kunlik reja:", fontSize = 14.sp, color = TextMuted)
                        Text("${detail.targetCount} ta", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Bajarilgan anjimaniya:", fontSize = 14.sp, color = TextMuted)
                        Text(
                            text = "${detail.completedTotal} ta",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDone) NeonGreen else AccentAmber
                        )
                    }

                    if (detail.targetCount > 30) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Ertalabki reja / bajarildi:", fontSize = 13.sp, color = TextMuted)
                            Text("$mTarget ta / ${detail.completedMorning} ta", fontSize = 13.sp, color = TextWhite)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Kechki reja / bajarildi:", fontSize = 13.sp, color = TextMuted)
                            Text("$eTarget ta / ${detail.completedEvening} ta", fontSize = 13.sp, color = TextWhite)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Holati:", fontSize = 14.sp, color = TextMuted)
                        Text(
                            text = when {
                                detail.isRestDay -> "Dam olish kuni 💤"
                                isDone -> "To‘liq bajarildi ✅"
                                detail.completedTotal > 0 -> "Qisman bajarildi ⏳"
                                else -> "Bajarilmagan"
                            },
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDone) NeonGreen else (if (detail.isRestDay) AccentBlue else AccentAmber)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDetailDialog = false
                        showEditDialog = true
                    }
                ) {
                    Text("Natijani tahrirlash", color = NeonGreen, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDetailDialog = false }) {
                    Text("Yopish", color = TextMuted)
                }
            }
        )
    }

    // Edit Day Count Dialog
    if (showEditDialog && selectedDayDetail != null) {
        val detail = selectedDayDetail!!
        var editCount by remember { mutableIntStateOf(detail.completedTotal) }

        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            containerColor = SurfaceDark,
            title = {
                Text("Natijani qo‘lda tuzatish", color = TextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "${DateUtils.formatDisplayDate(detail.date)} uchun bajarilgan anjimaniyalar soni:",
                        fontSize = 13.sp,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        IconButton(
                            onClick = { if (editCount > 0) editCount-- },
                            modifier = Modifier.background(SurfaceCard, CircleShape)
                        ) {
                            Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = TextWhite)
                        }

                        Text(
                            text = "$editCount ta",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonGreen,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )

                        IconButton(
                            onClick = { editCount++ },
                            modifier = Modifier.background(SurfaceCard, CircleShape)
                        ) {
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextWhite)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onManualUpdateDayCount(detail.date, editCount)
                        showEditDialog = false
                    }
                ) {
                    Text("Saqlash", color = NeonGreen, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) {
                    Text("Bekor qilish", color = TextMuted)
                }
            }
        )
    }
}
