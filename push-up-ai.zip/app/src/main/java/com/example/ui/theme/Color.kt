package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Neon Green Sports Palette
val NeonGreen = Color(0xFF00FF66)
val NeonGreenHover = Color(0xFF10E775)
val NeonGreenGlow = Color(0x3300FF66)
val NeonGreenDark = Color(0xFF05B548)

// Dark Surfaces
val BackgroundDark = Color(0xFF0B0E14)
val SurfaceDark = Color(0xFF131822)
val SurfaceCard = Color(0xFF19202D)
val SurfaceGlass = Color(0xCC171F2C)
val SurfaceBorder = Color(0xFF263242)

// Text & Accents
val TextWhite = Color(0xFFFFFFFF)
val TextMuted = Color(0xFF9AA4B2)
val TextDisabled = Color(0xFF556070)

val AccentAmber = Color(0xFFFFB020)
val AccentRed = Color(0xFFFF4842)
val AccentBlue = Color(0xFF1890FF)
