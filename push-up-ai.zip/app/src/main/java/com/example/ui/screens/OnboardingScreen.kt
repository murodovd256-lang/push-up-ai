package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonButton
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenGlow
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.util.DateUtils

@Composable
fun OnboardingScreen(
    onPlanCreated: (basePushups: Int, dailyIncrement: Int, morningHour: Int, morningMinute: Int, eveningHour: Int, eveningMinute: Int) -> Unit
) {
    var basePushups by remember { mutableIntStateOf(5) }
    var dailyIncrement by remember { mutableIntStateOf(2) }
    var morningHour by remember { mutableIntStateOf(7) }
    var morningMinute by remember { mutableIntStateOf(0) }
    var eveningHour by remember { mutableIntStateOf(21) }
    var eveningMinute by remember { mutableIntStateOf(0) }

    var showMorningTimeDialog by remember { mutableStateOf(false) }
    var showEveningTimeDialog by remember { mutableStateOf(false) }

    // Notification permission launcher for Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { /* granted or denied handled gracefully */ }
    )

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // App Icon / Header Badge
        Box(
            modifier = Modifier
                .size(72.dp)
                .background(
                    Brush.radialGradient(listOf(NeonGreenGlow, Color.Transparent)),
                    CircleShape
                )
                .border(2.dp, NeonGreen, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.FitnessCenter,
                contentDescription = null,
                tint = NeonGreen,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "PUSH-UP AI",
            fontSize = 32.sp,
            fontWeight = FontWeight.Black,
            color = TextWhite,
            letterSpacing = 1.sp
        )

        Text(
            text = "Har kuni kechagidan kuchliroq!",
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = NeonGreen,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Ilova noldan boshlanadi. Shaxsiy mashq rejangizni tuzing:",
            fontSize = 14.sp,
            color = TextMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // 1. Starting Pushups Card
        GlassCard(
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.FitnessCenter,
                        contentDescription = null,
                        tint = NeonGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "1-kun: Boshlang‘ich anjimaniya soni",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                }

                Text(
                    text = "Rejangiz boshlanadigan birinchi kungi mashqlar miqdori",
                    fontSize = 13.sp,
                    color = TextMuted,
                    modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { if (basePushups > 1) basePushups-- },
                        modifier = Modifier
                            .size(46.dp)
                            .background(SurfaceCard, CircleShape)
                            .border(1.dp, SurfaceBorder, CircleShape)
                            .testTag("onboarding_base_minus")
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Kamaytirish", tint = TextWhite)
                    }

                    Text(
                        text = "$basePushups ta",
                        fontSize = 34.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = NeonGreen,
                        modifier = Modifier
                            .padding(horizontal = 24.dp)
                            .testTag("onboarding_base_display")
                    )

                    IconButton(
                        onClick = { if (basePushups < 100) basePushups++ },
                        modifier = Modifier
                            .size(46.dp)
                            .background(SurfaceCard, CircleShape)
                            .border(1.dp, SurfaceBorder, CircleShape)
                            .testTag("onboarding_base_plus")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Oshirish", tint = TextWhite)
                    }
                }

                // Quick presets
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf(3, 5, 10, 15, 20).forEach { preset ->
                        val isSelected = basePushups == preset
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) NeonGreen else SurfaceCard)
                                .border(1.dp, if (isSelected) NeonGreen else SurfaceBorder, RoundedCornerShape(10.dp))
                                .clickable { basePushups = preset }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "$preset",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) BackgroundDark else TextWhite
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 2. Daily Increment Card
        GlassCard(
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.TrendingUp,
                        contentDescription = null,
                        tint = NeonGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Kunlik oshish miqdori",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                }

                Text(
                    text = "Har kuni reja nechta anjimaniyaga ko‘payadi (standart: +2)",
                    fontSize = 13.sp,
                    color = TextMuted,
                    modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    listOf(1, 2, 3, 5).forEach { inc ->
                        val isSelected = dailyIncrement == inc
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) NeonGreen else SurfaceCard)
                                .border(1.dp, if (isSelected) NeonGreen else SurfaceBorder, RoundedCornerShape(12.dp))
                                .clickable { dailyIncrement = inc }
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "+$inc",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) BackgroundDark else TextWhite
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 3. Notification Times Card
        GlassCard(
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = null,
                        tint = NeonGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Mashg‘ulot eslatma vaqtlari",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                }

                Text(
                    text = "Kunlik umumiy mashq 30 tadan oshganda ertalab (30%) va kechqurun (70%) taqsimlanadi",
                    fontSize = 13.sp,
                    color = TextMuted,
                    modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Morning time
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(SurfaceCard)
                            .border(1.dp, SurfaceBorder, RoundedCornerShape(14.dp))
                            .clickable { showMorningTimeDialog = true }
                            .padding(14.dp)
                    ) {
                        Column {
                            Text("Ertalab", fontSize = 12.sp, color = TextMuted)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = DateUtils.formatTime(morningHour, morningMinute),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeonGreen
                            )
                        }
                    }

                    // Evening time
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(SurfaceCard)
                            .border(1.dp, SurfaceBorder, RoundedCornerShape(14.dp))
                            .clickable { showEveningTimeDialog = true }
                            .padding(14.dp)
                    ) {
                        Column {
                            Text("Kechqurun", fontSize = 12.sp, color = TextMuted)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = DateUtils.formatTime(eveningHour, eveningMinute),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeonGreen
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Start Button
        NeonButton(
            text = "REJANI BOSHLASH 🚀",
            onClick = {
                // Request notification permission if Android 13+
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                onPlanCreated(
                    basePushups,
                    dailyIncrement,
                    morningHour,
                    morningMinute,
                    eveningHour,
                    eveningMinute
                )
            },
            modifier = Modifier.fillMaxWidth(),
            testTag = "onboarding_start_button"
        )

        Spacer(modifier = Modifier.height(16.dp))
    }

    // Morning Time Dialog
    if (showMorningTimeDialog) {
        TimePickerSimpleDialog(
            title = "Ertalabki mashg‘ulot vaqti",
            currentHour = morningHour,
            currentMinute = morningMinute,
            onDismiss = { showMorningTimeDialog = false },
            onConfirm = { h, m ->
                morningHour = h
                morningMinute = m
                showMorningTimeDialog = false
            }
        )
    }

    // Evening Time Dialog
    if (showEveningTimeDialog) {
        TimePickerSimpleDialog(
            title = "Kechki mashg‘ulot vaqti",
            currentHour = eveningHour,
            currentMinute = eveningMinute,
            onDismiss = { showEveningTimeDialog = false },
            onConfirm = { h, m ->
                eveningHour = h
                eveningMinute = m
                showEveningTimeDialog = false
            }
        )
    }
}

@Composable
fun TimePickerSimpleDialog(
    title: String,
    currentHour: Int,
    currentMinute: Int,
    onDismiss: () -> Unit,
    onConfirm: (hour: Int, minute: Int) -> Unit
) {
    var selectedHour by remember { mutableIntStateOf(currentHour) }
    var selectedMinute by remember { mutableIntStateOf(currentMinute) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        title = {
            Text(title, color = TextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        },
        text = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Hour
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(onClick = { selectedHour = (selectedHour + 1) % 24 }) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = NeonGreen)
                    }
                    Text(
                        text = String.format("%02d", selectedHour),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                    IconButton(onClick = { selectedHour = (selectedHour - 1 + 24) % 24 }) {
                        Icon(Icons.Default.Remove, contentDescription = null, tint = NeonGreen)
                    }
                }

                Text(":", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = TextMuted, modifier = Modifier.padding(horizontal = 16.dp))

                // Minute
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(onClick = { selectedMinute = (selectedMinute + 5) % 60 }) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = NeonGreen)
                    }
                    Text(
                        text = String.format("%02d", selectedMinute),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                    IconButton(onClick = { selectedMinute = (selectedMinute - 5 + 60) % 60 }) {
                        Icon(Icons.Default.Remove, contentDescription = null, tint = NeonGreen)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(selectedHour, selectedMinute) }) {
                Text("Saqlash", color = NeonGreen, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Bekor qilish", color = TextMuted)
            }
        }
    )
}
