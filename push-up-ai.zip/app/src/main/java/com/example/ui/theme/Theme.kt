package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val PushUpDarkColorScheme = darkColorScheme(
    primary = NeonGreen,
    onPrimary = BackgroundDark,
    primaryContainer = NeonGreenDark,
    onPrimaryContainer = Color.White,
    secondary = NeonGreenHover,
    onSecondary = BackgroundDark,
    secondaryContainer = SurfaceBorder,
    onSecondaryContainer = TextWhite,
    tertiary = AccentAmber,
    onTertiary = BackgroundDark,
    background = BackgroundDark,
    onBackground = TextWhite,
    surface = SurfaceDark,
    onSurface = TextWhite,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = TextMuted,
    outline = SurfaceBorder,
    outlineVariant = SurfaceGlass,
    error = AccentRed,
    onError = Color.White
)

@Composable
fun PushUpAiTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = PushUpDarkColorScheme,
        typography = Typography,
        content = content
    )
}
