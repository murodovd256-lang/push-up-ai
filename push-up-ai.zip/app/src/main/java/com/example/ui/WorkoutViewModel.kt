package com.example.ui

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.camera.PushupPoseAnalysisResult
import com.example.data.db.PushupDatabase
import com.example.data.model.DailyWorkoutEntity
import com.example.data.model.PushupLogEntity
import com.example.data.model.WorkoutPlanEntity
import com.example.data.repository.WorkoutRepository
import com.example.notification.WorkoutNotificationHelper
import com.example.notification.WorkoutReminderScheduler
import com.example.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Calendar

enum class AppScreen {
    ONBOARDING,
    HOME,
    CAMERA,
    CALENDAR,
    STATS,
    SETTINGS
}

data class UiWorkoutState(
    val isInitialized: Boolean = false,
    val plan: WorkoutPlanEntity? = null,
    val todayDate: String = DateUtils.getTodayDateString(),
    val todayWorkout: DailyWorkoutEntity? = null,
    val currentDayIndex: Int = 1,
    val totalTargetToday: Int = 5,
    val morningTargetToday: Int = 5,
    val eveningTargetToday: Int = 0,
    val completedTotalToday: Int = 0,
    val completedMorningToday: Int = 0,
    val completedEveningToday: Int = 0,
    val isRestDay: Boolean = false,
    val isPaused: Boolean = false,
    val allWorkouts: List<DailyWorkoutEntity> = emptyList(),
    val allLogs: List<PushupLogEntity> = emptyList(),
    val currentScreen: AppScreen = AppScreen.HOME,
    // Active Camera Session State
    val cameraSessionType: String = "MORNING", // MORNING, EVENING, GENERAL
    val cameraSessionReps: Int = 0,
    val cameraSessionTarget: Int = 5,
    val cameraElapsedSeconds: Int = 0,
    val latestPoseResult: PushupPoseAnalysisResult? = null,
    val isCameraSessionActive: Boolean = false,
    // Calendar selected date
    val selectedCalendarDate: String = DateUtils.getTodayDateString(),
    val selectedCalendarWorkout: DailyWorkoutEntity? = null
)

class WorkoutViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: WorkoutRepository
    private val vibrator: Vibrator?

    private val _uiState = MutableStateFlow(UiWorkoutState())
    val uiState: StateFlow<UiWorkoutState> = _uiState.asStateFlow()

    init {
        val db = PushupDatabase.getInstance(application)
        repository = WorkoutRepository(db.workoutDao())

        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = application.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            application.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

        WorkoutNotificationHelper.createNotificationChannel(application)

        observeData()
    }

    private fun observeData() {
        viewModelScope.launch {
            repository.planFlow.collect { plan ->
                val today = DateUtils.getTodayDateString()
                if (plan == null || !plan.isInitialized) {
                    _uiState.value = _uiState.value.copy(
                        isInitialized = false,
                        plan = null,
                        currentScreen = AppScreen.ONBOARDING
                    )
                } else {
                    val dayIndex = DateUtils.calculateDayIndex(plan.startDateMillis, today)
                    val target = plan.getTargetForDay(dayIndex)
                    val (mTarget, eTarget) = plan.getSessionTargets(target)

                    val prevScreen = _uiState.value.currentScreen
                    val nextScreen = if (prevScreen == AppScreen.ONBOARDING) AppScreen.HOME else prevScreen

                    _uiState.value = _uiState.value.copy(
                        isInitialized = true,
                        plan = plan,
                        currentDayIndex = dayIndex,
                        totalTargetToday = target,
                        morningTargetToday = mTarget,
                        eveningTargetToday = eTarget,
                        isPaused = plan.isPaused,
                        currentScreen = nextScreen
                    )
                    // Fetch today's workout record
                    refreshTodayWorkout(today)
                }
            }
        }

        viewModelScope.launch {
            repository.allDailyWorkoutsFlow.collect { workouts ->
                val today = DateUtils.getTodayDateString()
                val todayItem = workouts.find { it.date == today }
                val selectedItem = workouts.find { it.date == _uiState.value.selectedCalendarDate }

                _uiState.value = _uiState.value.copy(
                    allWorkouts = workouts,
                    todayWorkout = todayItem,
                    completedTotalToday = todayItem?.completedTotal ?: 0,
                    completedMorningToday = todayItem?.completedMorning ?: 0,
                    completedEveningToday = todayItem?.completedEvening ?: 0,
                    isRestDay = todayItem?.isRestDay ?: false,
                    selectedCalendarWorkout = selectedItem
                )
            }
        }

        viewModelScope.launch {
            repository.allLogsFlow.collect { logs ->
                _uiState.value = _uiState.value.copy(allLogs = logs)
            }
        }
    }

    fun navigateTo(screen: AppScreen) {
        if (!_uiState.value.isInitialized && screen != AppScreen.ONBOARDING) {
            _uiState.value = _uiState.value.copy(currentScreen = AppScreen.ONBOARDING)
        } else {
            _uiState.value = _uiState.value.copy(currentScreen = screen)
        }
    }

    fun initializeNewPlan(
        basePushups: Int,
        dailyIncrement: Int,
        morningHour: Int,
        morningMinute: Int,
        eveningHour: Int,
        eveningMinute: Int
    ) {
        viewModelScope.launch {
            val plan = repository.initializePlan(
                basePushups = basePushups,
                dailyIncrement = dailyIncrement,
                morningHour = morningHour,
                morningMinute = morningMinute,
                eveningHour = eveningHour,
                eveningMinute = eveningMinute
            )
            // Schedule notifications
            WorkoutReminderScheduler.scheduleReminders(
                context = getApplication(),
                morningHour = morningHour,
                morningMinute = morningMinute,
                eveningHour = eveningHour,
                eveningMinute = eveningMinute,
                enabled = true
            )
            _uiState.value = _uiState.value.copy(
                isInitialized = true,
                plan = plan,
                currentScreen = AppScreen.HOME
            )
        }
    }

    private suspend fun refreshTodayWorkout(today: String) {
        val record = repository.getOrCreateDailyWorkout(today)
        _uiState.value = _uiState.value.copy(
            todayWorkout = record,
            completedTotalToday = record.completedTotal,
            completedMorningToday = record.completedMorning,
            completedEveningToday = record.completedEvening,
            isRestDay = record.isRestDay
        )
    }

    fun startCameraSession(sessionType: String) {
        val target = if (sessionType == "MORNING") {
            _uiState.value.morningTargetToday
        } else if (sessionType == "EVENING") {
            _uiState.value.eveningTargetToday
        } else {
            _uiState.value.totalTargetToday
        }

        _uiState.value = _uiState.value.copy(
            currentScreen = AppScreen.CAMERA,
            cameraSessionType = sessionType,
            cameraSessionReps = 0,
            cameraSessionTarget = if (target > 0) target else _uiState.value.totalTargetToday,
            cameraElapsedSeconds = 0,
            isCameraSessionActive = true,
            latestPoseResult = null
        )
    }

    fun updatePoseResult(result: PushupPoseAnalysisResult) {
        _uiState.value = _uiState.value.copy(
            latestPoseResult = result,
            cameraSessionReps = result.repCount
        )
    }

    fun onRepCompleted(count: Int) {
        _uiState.value = _uiState.value.copy(cameraSessionReps = count)
        triggerHapticRep()
    }

    fun manualAdjustCameraReps(delta: Int) {
        val current = _uiState.value.cameraSessionReps
        val updated = maxOf(0, current + delta)
        _uiState.value = _uiState.value.copy(cameraSessionReps = updated)
    }

    fun finishCameraSession(accuracyScore: Int = 95) {
        val count = _uiState.value.cameraSessionReps
        val type = _uiState.value.cameraSessionType
        val duration = _uiState.value.cameraElapsedSeconds
        val today = DateUtils.getTodayDateString()

        if (count > 0) {
            viewModelScope.launch {
                repository.recordPushups(
                    date = today,
                    count = count,
                    sessionType = type,
                    durationSeconds = duration,
                    accuracyPercent = accuracyScore
                )
            }
        }

        _uiState.value = _uiState.value.copy(
            isCameraSessionActive = false,
            currentScreen = AppScreen.HOME
        )
    }

    fun cancelCameraSession() {
        _uiState.value = _uiState.value.copy(
            isCameraSessionActive = false,
            currentScreen = AppScreen.HOME
        )
    }

    fun manualAddPushups(count: Int, sessionType: String = "GENERAL") {
        if (count <= 0) return
        val today = DateUtils.getTodayDateString()
        viewModelScope.launch {
            repository.recordPushups(
                date = today,
                count = count,
                sessionType = sessionType
            )
        }
    }

    fun manualSetDayCount(date: String, newTotal: Int) {
        viewModelScope.launch {
            repository.manualAdjustCount(date, newTotal)
        }
    }

    fun toggleRestDayToday() {
        val today = DateUtils.getTodayDateString()
        viewModelScope.launch {
            repository.toggleRestDay(today)
        }
    }

    fun selectCalendarDate(date: String) {
        val item = _uiState.value.allWorkouts.find { it.date == date }
        _uiState.value = _uiState.value.copy(
            selectedCalendarDate = date,
            selectedCalendarWorkout = item
        )
    }

    fun updateTimes(mHour: Int, mMin: Int, eHour: Int, eMin: Int) {
        val currentPlan = _uiState.value.plan ?: return
        val updated = currentPlan.copy(
            morningTimeHour = mHour,
            morningTimeMinute = mMin,
            eveningTimeHour = eHour,
            eveningTimeMinute = eMin
        )
        viewModelScope.launch {
            repository.updatePlan(updated)
            WorkoutReminderScheduler.scheduleReminders(
                context = getApplication(),
                morningHour = mHour,
                morningMinute = mMin,
                eveningHour = eHour,
                eveningMinute = eMin,
                enabled = updated.notificationsEnabled && !updated.isPaused
            )
        }
    }

    fun updateIncrementAndBase(base: Int, increment: Int) {
        val currentPlan = _uiState.value.plan ?: return
        val updated = currentPlan.copy(
            basePushups = base,
            dailyIncrement = increment
        )
        viewModelScope.launch {
            repository.updatePlan(updated)
        }
    }

    fun togglePause() {
        val currentPlan = _uiState.value.plan ?: return
        val newPaused = !currentPlan.isPaused
        viewModelScope.launch {
            repository.setPaused(newPaused)
            WorkoutReminderScheduler.scheduleReminders(
                context = getApplication(),
                morningHour = currentPlan.morningTimeHour,
                morningMinute = currentPlan.morningTimeMinute,
                eveningHour = currentPlan.eveningTimeHour,
                eveningMinute = currentPlan.eveningTimeMinute,
                enabled = currentPlan.notificationsEnabled && !newPaused
            )
        }
    }

    fun toggleNotifications(enabled: Boolean) {
        val currentPlan = _uiState.value.plan ?: return
        val updated = currentPlan.copy(notificationsEnabled = enabled)
        viewModelScope.launch {
            repository.updatePlan(updated)
            WorkoutReminderScheduler.scheduleReminders(
                context = getApplication(),
                morningHour = updated.morningTimeHour,
                morningMinute = updated.morningTimeMinute,
                eveningHour = updated.eveningTimeHour,
                eveningMinute = updated.eveningTimeMinute,
                enabled = enabled && !updated.isPaused
            )
        }
    }

    fun testReminder(isMorning: Boolean) {
        val total = _uiState.value.totalTargetToday
        val (mTarget, eTarget) = _uiState.value.plan?.getSessionTargets(total) ?: Pair(total, 0)
        WorkoutNotificationHelper.showWorkoutReminder(
            context = getApplication(),
            isMorning = isMorning,
            targetReps = if (isMorning) mTarget else (if (eTarget > 0) eTarget else total)
        )
    }

    fun resetAllDataToZero() {
        viewModelScope.launch {
            repository.resetAllData()
            _uiState.value = UiWorkoutState(
                isInitialized = false,
                plan = null,
                currentScreen = AppScreen.ONBOARDING
            )
        }
    }

    suspend fun exportDataJson(): String {
        return repository.exportDataJson()
    }

    suspend fun importDataJson(jsonStr: String): Boolean {
        return repository.importDataJson(jsonStr)
    }

    private fun triggerHapticRep() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(80)
            }
        } catch (e: Exception) {
            // Ignore haptic failures
        }
    }
}
