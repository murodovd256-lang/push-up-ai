package com.example.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.db.PushupDatabase
import com.example.util.DateUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class WorkoutReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        val isMorning = intent.getBooleanExtra("IS_MORNING", true)

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = PushupDatabase.getInstance(context)
                val plan = db.workoutDao().getPlan()

                if (plan != null && plan.isInitialized) {
                    if (action == Intent.ACTION_BOOT_COMPLETED) {
                        // Reschedule both alarms after phone reboot
                        WorkoutReminderScheduler.scheduleReminders(
                            context = context,
                            morningHour = plan.morningTimeHour,
                            morningMinute = plan.morningTimeMinute,
                            eveningHour = plan.eveningTimeHour,
                            eveningMinute = plan.eveningTimeMinute,
                            enabled = plan.notificationsEnabled && !plan.isPaused
                        )
                    } else if (action == "com.example.ACTION_WORKOUT_REMINDER") {
                        if (plan.notificationsEnabled && !plan.isPaused) {
                            val today = DateUtils.getTodayDateString()
                            val todayWorkout = db.workoutDao().getDailyWorkout(today)
                            val dayNumber = DateUtils.calculateDayIndex(plan.startDateMillis, today)
                            val totalTarget = plan.getTargetForDay(dayNumber)
                            val (morningTarget, eveningTarget) = plan.getSessionTargets(totalTarget)

                            // Check if already completed:
                            // If morning: check if morning completed or total completed
                            // If evening: check if evening completed or total completed
                            val shouldNotify = if (isMorning) {
                                (todayWorkout == null || todayWorkout.completedMorning < morningTarget) &&
                                        (todayWorkout == null || !todayWorkout.isCompleted) &&
                                        (todayWorkout == null || !todayWorkout.isRestDay)
                            } else {
                                // If evening is 0 (i.e. total <= 30), do not trigger evening notification
                                eveningTarget > 0 &&
                                        (todayWorkout == null || todayWorkout.completedEvening < eveningTarget) &&
                                        (todayWorkout == null || !todayWorkout.isCompleted) &&
                                        (todayWorkout == null || !todayWorkout.isRestDay)
                            }

                            if (shouldNotify) {
                                val targetReps = if (isMorning) morningTarget else eveningTarget
                                WorkoutNotificationHelper.showWorkoutReminder(
                                    context = context,
                                    isMorning = isMorning,
                                    targetReps = targetReps
                                )
                            }

                            // Re-schedule alarm for tomorrow
                            WorkoutReminderScheduler.scheduleReminders(
                                context = context,
                                morningHour = plan.morningTimeHour,
                                morningMinute = plan.morningTimeMinute,
                                eveningHour = plan.eveningTimeHour,
                                eveningMinute = plan.eveningTimeMinute,
                                enabled = plan.notificationsEnabled
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                // Ignore background errors
            } finally {
                pendingResult.finish()
            }
        }
    }
}
