package com.example.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R

object WorkoutNotificationHelper {
    const val CHANNEL_ID = "pushup_workout_reminders"
    const val NOTIFICATION_ID_MORNING = 1001
    const val NOTIFICATION_ID_EVENING = 1002

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = context.getString(R.string.notification_channel_name)
            val descriptionText = context.getString(R.string.notification_channel_desc)
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 150, 250)
            }
            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun showWorkoutReminder(
        context: Context,
        isMorning: Boolean,
        targetReps: Int
    ) {
        val title = if (isMorning) "Xayrli tong! 🌅" else "Kechki mashg‘ulot vaqti! 🌙"
        val message = if (isMorning) {
            "Bugungi anjimaniya vaqti keldi. Rejangiz: $targetReps ta."
        } else {
            "Bugungi rejangizni davom ettiring: $targetReps ta."
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("OPEN_WORKOUT", true)
            putExtra("IS_MORNING", isMorning)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            if (isMorning) NOTIFICATION_ID_MORNING else NOTIFICATION_ID_EVENING,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setVibrate(longArrayOf(0, 300, 200, 300))
            .build()

        try {
            val notificationManager = NotificationManagerCompat.from(context)
            val notificationId = if (isMorning) NOTIFICATION_ID_MORNING else NOTIFICATION_ID_EVENING
            notificationManager.notify(notificationId, notification)
        } catch (e: SecurityException) {
            // Permission might be revoked by user
        }
    }
}
