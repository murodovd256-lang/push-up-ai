package com.example.notification

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object WorkoutReminderScheduler {
    const val REQUEST_CODE_MORNING = 2001
    const val REQUEST_CODE_EVENING = 2002

    fun scheduleReminders(
        context: Context,
        morningHour: Int,
        morningMinute: Int,
        eveningHour: Int,
        eveningMinute: Int,
        enabled: Boolean
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        // Cancel previous alarms first
        cancelAlarm(context, alarmManager, REQUEST_CODE_MORNING, isMorning = true)
        cancelAlarm(context, alarmManager, REQUEST_CODE_EVENING, isMorning = false)

        if (!enabled) return

        scheduleSingleAlarm(context, alarmManager, morningHour, morningMinute, REQUEST_CODE_MORNING, isMorning = true)
        scheduleSingleAlarm(context, alarmManager, eveningHour, eveningMinute, REQUEST_CODE_EVENING, isMorning = false)
    }

    private fun scheduleSingleAlarm(
        context: Context,
        alarmManager: AlarmManager,
        hour: Int,
        minute: Int,
        requestCode: Int,
        isMorning: Boolean
    ) {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (before(Calendar.getInstance())) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        val intent = Intent(context, WorkoutReminderReceiver::class.java).apply {
            action = "com.example.ACTION_WORKOUT_REMINDER"
            putExtra("IS_MORNING", isMorning)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            }
        } catch (e: SecurityException) {
            // If exact alarm permission is restricted on Android 12+, fallback to normal set
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                pendingIntent
            )
        }
    }

    private fun cancelAlarm(
        context: Context,
        alarmManager: AlarmManager,
        requestCode: Int,
        isMorning: Boolean
    ) {
        val intent = Intent(context, WorkoutReminderReceiver::class.java).apply {
            action = "com.example.ACTION_WORKOUT_REMINDER"
            putExtra("IS_MORNING", isMorning)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }
}
