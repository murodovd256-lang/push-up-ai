package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.AppScreen
import com.example.ui.WorkoutViewModel
import com.example.ui.components.AppBottomNavBar
import com.example.ui.components.NavItem
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.CameraScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StatsScreen
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.PushUpAiTheme

class MainActivity : ComponentActivity() {

    private val viewModel: WorkoutViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Handle notification deep link click
        val openWorkout = intent.getBooleanExtra("OPEN_WORKOUT", false)
        val isMorning = intent.getBooleanExtra("IS_MORNING", true)

        setContent {
            PushUpAiTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                LaunchedEffect(openWorkout) {
                    if (openWorkout && uiState.isInitialized) {
                        viewModel.startCameraSession(if (isMorning) "MORNING" else "EVENING")
                    }
                }

                MainAppRoot(
                    viewModel = viewModel
                )
            }
        }
    }
}

@Composable
fun MainAppRoot(viewModel: WorkoutViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Handle system back gesture
    if (uiState.currentScreen != AppScreen.HOME && uiState.currentScreen != AppScreen.ONBOARDING) {
        BackHandler {
            viewModel.navigateTo(AppScreen.HOME)
        }
    }

    val navItems = listOf(
        NavItem(AppScreen.HOME, "Asosiy", Icons.Default.Home),
        NavItem(AppScreen.CAMERA, "AI Kamera", Icons.Default.Videocam),
        NavItem(AppScreen.CALENDAR, "Kalendar", Icons.Default.CalendarMonth),
        NavItem(AppScreen.STATS, "Statistika", Icons.Default.BarChart),
        NavItem(AppScreen.SETTINGS, "Sozlamalar", Icons.Default.Settings)
    )

    val showBottomBar = uiState.isInitialized && uiState.currentScreen != AppScreen.CAMERA && uiState.currentScreen != AppScreen.ONBOARDING

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (showBottomBar) {
                AppBottomNavBar(
                    currentScreen = uiState.currentScreen,
                    items = navItems,
                    onSelectScreen = { screen ->
                        if (screen == AppScreen.CAMERA) {
                            viewModel.startCameraSession("GENERAL")
                        } else {
                            viewModel.navigateTo(screen)
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundDark)
                .padding(innerPadding)
        ) {
            Crossfade(targetState = uiState.currentScreen, label = "ScreenTransition") { screen ->
                when (screen) {
                    AppScreen.ONBOARDING -> {
                        OnboardingScreen(
                            onPlanCreated = { base, inc, mH, mM, eH, eM ->
                                viewModel.initializeNewPlan(base, inc, mH, mM, eH, eM)
                            }
                        )
                    }

                    AppScreen.HOME -> {
                        HomeScreen(
                            uiState = uiState,
                            onStartCameraSession = { sessionType ->
                                viewModel.startCameraSession(sessionType)
                            },
                            onManualAdd = { count, sessionType ->
                                viewModel.manualAddPushups(count, sessionType)
                            },
                            onToggleRestDay = {
                                viewModel.toggleRestDayToday()
                            }
                        )
                    }

                    AppScreen.CAMERA -> {
                        CameraScreen(
                            uiState = uiState,
                            onPoseUpdated = { result ->
                                viewModel.updatePoseResult(result)
                            },
                            onRepCompleted = { count ->
                                viewModel.onRepCompleted(count)
                            },
                            onAdjustManualCount = { delta ->
                                viewModel.manualAdjustCameraReps(delta)
                            },
                            onFinishSession = { accuracy ->
                                viewModel.finishCameraSession(accuracy)
                            },
                            onCancelSession = {
                                viewModel.cancelCameraSession()
                            }
                        )
                    }

                    AppScreen.CALENDAR -> {
                        CalendarScreen(
                            uiState = uiState,
                            onSelectDate = { date ->
                                viewModel.selectCalendarDate(date)
                            },
                            onManualUpdateDayCount = { date, newTotal ->
                                viewModel.manualSetDayCount(date, newTotal)
                            }
                        )
                    }

                    AppScreen.STATS -> {
                        StatsScreen(uiState = uiState)
                    }

                    AppScreen.SETTINGS -> {
                        SettingsScreen(
                            uiState = uiState,
                            onUpdateTimes = { mH, mM, eH, eM ->
                                viewModel.updateTimes(mH, mM, eH, eM)
                            },
                            onUpdateBaseAndIncrement = { base, inc ->
                                viewModel.updateIncrementAndBase(base, inc)
                            },
                            onTogglePause = {
                                viewModel.togglePause()
                            },
                            onToggleNotifications = { enabled ->
                                viewModel.toggleNotifications(enabled)
                            },
                            onTestNotification = { isMorning ->
                                viewModel.testReminder(isMorning)
                            },
                            onResetAllData = {
                                viewModel.resetAllDataToZero()
                            },
                            onExportData = {
                                viewModel.exportDataJson()
                            },
                            onImportData = { json ->
                                viewModel.importDataJson(json)
                            }
                        )
                    }
                }
            }
        }
    }
}
