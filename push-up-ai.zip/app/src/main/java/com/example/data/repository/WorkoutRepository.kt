package com.example.data.repository

import com.example.data.db.WorkoutDao
import com.example.data.model.DailyWorkoutEntity
import com.example.data.model.PushupLogEntity
import com.example.data.model.WorkoutPlanEntity
import com.example.util.DateUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class WorkoutRepository(private val dao: WorkoutDao) {

    val planFlow: Flow<WorkoutPlanEntity?> = dao.getPlanFlow()
    val allDailyWorkoutsFlow: Flow<List<DailyWorkoutEntity>> = dao.getAllDailyWorkoutsFlow()
    val allLogsFlow: Flow<List<PushupLogEntity>> = dao.getAllLogsFlow()

    suspend fun getPlan(): WorkoutPlanEntity? = withContext(Dispatchers.IO) {
        dao.getPlan()
    }

    suspend fun initializePlan(
        basePushups: Int,
        dailyIncrement: Int,
        morningHour: Int,
        morningMinute: Int,
        eveningHour: Int,
        eveningMinute: Int
    ): WorkoutPlanEntity = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val plan = WorkoutPlanEntity(
            id = 1,
            isInitialized = true,
            startDateMillis = now,
            basePushups = basePushups,
            dailyIncrement = dailyIncrement,
            morningTimeHour = morningHour,
            morningTimeMinute = morningMinute,
            eveningTimeHour = eveningHour,
            eveningTimeMinute = eveningMinute,
            isPaused = false,
            notificationsEnabled = true
        )
        dao.savePlan(plan)

        // Initialize Day 1 for today
        val today = DateUtils.getTodayDateString()
        val existingToday = dao.getDailyWorkout(today)
        if (existingToday == null) {
            val day1Workout = DailyWorkoutEntity(
                date = today,
                dayNumber = 1,
                targetCount = plan.getTargetForDay(1),
                completedTotal = 0,
                completedMorning = 0,
                completedEvening = 0,
                isRestDay = false,
                isCompleted = false
            )
            dao.saveDailyWorkout(day1Workout)
        }
        plan
    }

    suspend fun updatePlan(plan: WorkoutPlanEntity) = withContext(Dispatchers.IO) {
        dao.savePlan(plan)
    }

    suspend fun getOrCreateDailyWorkout(date: String): DailyWorkoutEntity = withContext(Dispatchers.IO) {
        val existing = dao.getDailyWorkout(date)
        if (existing != null) return@withContext existing

        val plan = dao.getPlan()
        if (plan != null && plan.isInitialized) {
            val dayNumber = DateUtils.calculateDayIndex(plan.startDateMillis, date)
            val target = plan.getTargetForDay(dayNumber)
            val newWorkout = DailyWorkoutEntity(
                date = date,
                dayNumber = dayNumber,
                targetCount = target,
                completedTotal = 0,
                completedMorning = 0,
                completedEvening = 0,
                isRestDay = false,
                isCompleted = false
            )
            dao.saveDailyWorkout(newWorkout)
            newWorkout
        } else {
            DailyWorkoutEntity(
                date = date,
                dayNumber = 1,
                targetCount = 5,
                completedTotal = 0,
                completedMorning = 0,
                completedEvening = 0,
                isRestDay = false,
                isCompleted = false
            )
        }
    }

    suspend fun recordPushups(
        date: String,
        count: Int,
        sessionType: String,
        durationSeconds: Int = 0,
        accuracyPercent: Int = 100
    ): DailyWorkoutEntity = withContext(Dispatchers.IO) {
        val current = getOrCreateDailyWorkout(date)
        val newTotal = current.completedTotal + count
        val newMorning = if (sessionType.equals("MORNING", ignoreCase = true)) {
            current.completedMorning + count
        } else {
            current.completedMorning
        }
        val newEvening = if (sessionType.equals("EVENING", ignoreCase = true)) {
            current.completedEvening + count
        } else {
            current.completedEvening
        }
        val isCompleted = newTotal >= current.targetCount

        val updatedWorkout = current.copy(
            completedTotal = newTotal,
            completedMorning = newMorning,
            completedEvening = newEvening,
            isCompleted = isCompleted,
            updatedAtMillis = System.currentTimeMillis()
        )
        dao.saveDailyWorkout(updatedWorkout)

        // Insert log
        dao.insertLog(
            PushupLogEntity(
                date = date,
                timestamp = System.currentTimeMillis(),
                sessionType = sessionType,
                count = count,
                durationSeconds = durationSeconds,
                accuracyPercent = accuracyPercent
            )
        )

        updatedWorkout
    }

    suspend fun manualAdjustCount(date: String, newTotal: Int) = withContext(Dispatchers.IO) {
        val current = getOrCreateDailyWorkout(date)
        val validTotal = maxOf(0, newTotal)
        val isCompleted = validTotal >= current.targetCount
        val updated = current.copy(
            completedTotal = validTotal,
            isCompleted = isCompleted,
            updatedAtMillis = System.currentTimeMillis()
        )
        dao.saveDailyWorkout(updated)
    }

    suspend fun toggleRestDay(date: String): DailyWorkoutEntity = withContext(Dispatchers.IO) {
        val current = getOrCreateDailyWorkout(date)
        val updated = current.copy(
            isRestDay = !current.isRestDay,
            updatedAtMillis = System.currentTimeMillis()
        )
        dao.saveDailyWorkout(updated)
        updated
    }

    suspend fun setPaused(isPaused: Boolean) = withContext(Dispatchers.IO) {
        val plan = dao.getPlan() ?: return@withContext
        dao.savePlan(plan.copy(isPaused = isPaused))
    }

    suspend fun resetAllData() = withContext(Dispatchers.IO) {
        dao.clearPlan()
        dao.clearDailyWorkouts()
        dao.clearLogs()
    }

    suspend fun exportDataJson(): String = withContext(Dispatchers.IO) {
        val plan = dao.getPlan()
        val workouts = dao.getAllDailyWorkoutsFlow()
        // Simple JSON serialization
        val root = JSONObject()
        val planObj = JSONObject().apply {
            put("isInitialized", plan?.isInitialized ?: false)
            put("basePushups", plan?.basePushups ?: 5)
            put("dailyIncrement", plan?.dailyIncrement ?: 2)
            put("morningTimeHour", plan?.morningTimeHour ?: 7)
            put("morningTimeMinute", plan?.morningTimeMinute ?: 0)
            put("eveningTimeHour", plan?.eveningTimeHour ?: 21)
            put("eveningTimeMinute", plan?.eveningTimeMinute ?: 0)
            put("isPaused", plan?.isPaused ?: false)
            put("notificationsEnabled", plan?.notificationsEnabled ?: true)
        }
        root.put("plan", planObj)
        root.toString(2)
    }

    suspend fun importDataJson(jsonStr: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonStr)
            val planObj = root.optJSONObject("plan") ?: return@withContext false
            val currentPlan = dao.getPlan() ?: WorkoutPlanEntity()
            val newPlan = currentPlan.copy(
                isInitialized = planObj.optBoolean("isInitialized", true),
                basePushups = planObj.optInt("basePushups", 5),
                dailyIncrement = planObj.optInt("dailyIncrement", 2),
                morningTimeHour = planObj.optInt("morningTimeHour", 7),
                morningTimeMinute = planObj.optInt("morningTimeMinute", 0),
                eveningTimeHour = planObj.optInt("eveningTimeHour", 21),
                eveningTimeMinute = planObj.optInt("eveningTimeMinute", 0),
                isPaused = planObj.optBoolean("isPaused", false),
                notificationsEnabled = planObj.optBoolean("notificationsEnabled", true)
            )
            dao.savePlan(newPlan)
            true
        } catch (e: Exception) {
            false
        }
    }
}
