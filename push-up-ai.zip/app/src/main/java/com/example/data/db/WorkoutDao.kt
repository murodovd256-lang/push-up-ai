package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.DailyWorkoutEntity
import com.example.data.model.PushupLogEntity
import com.example.data.model.WorkoutPlanEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkoutDao {
    @Query("SELECT * FROM workout_plan WHERE id = 1 LIMIT 1")
    fun getPlanFlow(): Flow<WorkoutPlanEntity?>

    @Query("SELECT * FROM workout_plan WHERE id = 1 LIMIT 1")
    suspend fun getPlan(): WorkoutPlanEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePlan(plan: WorkoutPlanEntity)

    @Query("SELECT * FROM daily_workouts ORDER BY date ASC")
    fun getAllDailyWorkoutsFlow(): Flow<List<DailyWorkoutEntity>>

    @Query("SELECT * FROM daily_workouts WHERE date = :date LIMIT 1")
    suspend fun getDailyWorkout(date: String): DailyWorkoutEntity?

    @Query("SELECT * FROM daily_workouts WHERE date = :date LIMIT 1")
    fun getDailyWorkoutFlow(date: String): Flow<DailyWorkoutEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveDailyWorkout(workout: DailyWorkoutEntity)

    @Insert
    suspend fun insertLog(log: PushupLogEntity)

    @Query("SELECT * FROM pushup_logs ORDER BY timestamp DESC")
    fun getAllLogsFlow(): Flow<List<PushupLogEntity>>

    @Query("SELECT * FROM pushup_logs WHERE date = :date ORDER BY timestamp ASC")
    fun getLogsForDateFlow(date: String): Flow<List<PushupLogEntity>>

    @Query("DELETE FROM daily_workouts")
    suspend fun clearDailyWorkouts()

    @Query("DELETE FROM pushup_logs")
    suspend fun clearLogs()

    @Query("DELETE FROM workout_plan")
    suspend fun clearPlan()
}
