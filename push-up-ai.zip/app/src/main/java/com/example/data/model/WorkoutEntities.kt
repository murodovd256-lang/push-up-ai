package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "workout_plan")
data class WorkoutPlanEntity(
    @PrimaryKey
    val id: Int = 1,
    val isInitialized: Boolean = false,
    val startDateMillis: Long = System.currentTimeMillis(),
    val basePushups: Int = 5,
    val dailyIncrement: Int = 2,
    val morningTimeHour: Int = 7,
    val morningTimeMinute: Int = 0,
    val eveningTimeHour: Int = 21,
    val eveningTimeMinute: Int = 0,
    val isPaused: Boolean = false,
    val notificationsEnabled: Boolean = true
) {
    /**
     * Calculates the target for a given 1-based day index.
     * Day 1: basePushups (default 5)
     * Day 2: basePushups + increment (default 7)
     * Day N: basePushups + (N - 1) * increment
     */
    fun getTargetForDay(dayNumber: Int): Int {
        if (dayNumber < 1) return basePushups
        return basePushups + (dayNumber - 1) * dailyIncrement
    }

    /**
     * Calculates session distribution based on the total target:
     * - If total <= 30: 100% morning session (morning = total, evening = 0)
     * - If total > 30: 30% morning, 70% evening (sum strictly preserved)
     */
    fun getSessionTargets(totalTarget: Int): Pair<Int, Int> {
        return if (totalTarget <= 30) {
            Pair(totalTarget, 0)
        } else {
            val morning = Math.round(totalTarget * 0.30f)
            val evening = totalTarget - morning
            Pair(morning, evening)
        }
    }
}

@Entity(tableName = "daily_workouts")
data class DailyWorkoutEntity(
    @PrimaryKey
    val date: String, // "yyyy-MM-dd"
    val dayNumber: Int,
    val targetCount: Int,
    val completedTotal: Int = 0,
    val completedMorning: Int = 0,
    val completedEvening: Int = 0,
    val isRestDay: Boolean = false,
    val isCompleted: Boolean = false,
    val notes: String = "",
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "pushup_logs")
data class PushupLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: String, // "yyyy-MM-dd"
    val timestamp: Long = System.currentTimeMillis(),
    val sessionType: String, // "MORNING", "EVENING", "GENERAL"
    val count: Int,
    val durationSeconds: Int = 0,
    val accuracyPercent: Int = 100
)
