package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.DailyWorkoutEntity
import com.example.data.model.PushupLogEntity
import com.example.data.model.WorkoutPlanEntity

@Database(
    entities = [
        WorkoutPlanEntity::class,
        DailyWorkoutEntity::class,
        PushupLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class PushupDatabase : RoomDatabase() {
    abstract fun workoutDao(): WorkoutDao

    companion object {
        @Volatile
        private var INSTANCE: PushupDatabase? = null

        fun getInstance(context: Context): PushupDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PushupDatabase::class.java,
                    "pushup_ai_database.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
