package com.example.camera

import android.graphics.PointF
import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseLandmark
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import kotlin.math.abs
import kotlin.math.atan2

data class PoseLandmarkPoint(
    val x: Float,
    val y: Float,
    val likelihood: Float
)

data class PushupPoseAnalysisResult(
    val repCount: Int,
    val currentElbowAngle: Double,
    val isDownState: Boolean,
    val isBodyDetected: Boolean,
    val formFeedback: String,
    val formAccuracyScore: Int,
    val landmarks: Map<Int, PoseLandmarkPoint>,
    val imageWidth: Int,
    val imageHeight: Int,
    val rotationDegrees: Int,
    val isRepJustCompleted: Boolean = false
)

class PushupPoseAnalyzer(
    private val onResult: (PushupPoseAnalysisResult) -> Unit,
    private val onRepCompleted: (Int) -> Unit
) : ImageAnalysis.Analyzer {

    private val options = PoseDetectorOptions.Builder()
        .setDetectorMode(PoseDetectorOptions.STREAM_MODE)
        .build()

    private val detector = PoseDetection.getClient(options)

    private var repCount = 0
    private var isDown = false
    private var hasReachedLowestPoint = false
    private var lowestAngleRecorded = 180.0

    fun resetCount(startFrom: Int = 0) {
        repCount = startFrom
        isDown = false
        hasReachedLowestPoint = false
        lowestAngleRecorded = 180.0
    }

    fun adjustRepCount(delta: Int) {
        repCount = maxOf(0, repCount + delta)
    }

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage != null) {
            val rotationDegrees = imageProxy.imageInfo.rotationDegrees
            val inputImage = InputImage.fromMediaImage(mediaImage, rotationDegrees)

            detector.process(inputImage)
                .addOnSuccessListener { pose ->
                    processPose(pose, imageProxy.width, imageProxy.height, rotationDegrees)
                }
                .addOnFailureListener {
                    // Ignore transient frames
                }
                .addOnCompleteListener {
                    imageProxy.close()
                }
        } else {
            imageProxy.close()
        }
    }

    private fun processPose(
        pose: Pose,
        imageWidth: Int,
        imageHeight: Int,
        rotationDegrees: Int
    ) {
        val leftShoulder = pose.getPoseLandmark(PoseLandmark.LEFT_SHOULDER)
        val rightShoulder = pose.getPoseLandmark(PoseLandmark.RIGHT_SHOULDER)
        val leftElbow = pose.getPoseLandmark(PoseLandmark.LEFT_ELBOW)
        val rightElbow = pose.getPoseLandmark(PoseLandmark.RIGHT_ELBOW)
        val leftWrist = pose.getPoseLandmark(PoseLandmark.LEFT_WRIST)
        val rightWrist = pose.getPoseLandmark(PoseLandmark.RIGHT_WRIST)
        val leftHip = pose.getPoseLandmark(PoseLandmark.LEFT_HIP)
        val rightHip = pose.getPoseLandmark(PoseLandmark.RIGHT_HIP)

        val landmarksMap = mutableMapOf<Int, PoseLandmarkPoint>()
        pose.allPoseLandmarks.forEach { landmark ->
            landmarksMap[landmark.landmarkType] = PoseLandmarkPoint(
                x = landmark.position.x,
                y = landmark.position.y,
                likelihood = landmark.inFrameLikelihood
            )
        }

        // Check if upper body is in frame
        val leftArmVisible = (leftShoulder?.inFrameLikelihood ?: 0f) > 0.45f &&
                (leftElbow?.inFrameLikelihood ?: 0f) > 0.45f &&
                (leftWrist?.inFrameLikelihood ?: 0f) > 0.45f

        val rightArmVisible = (rightShoulder?.inFrameLikelihood ?: 0f) > 0.45f &&
                (rightElbow?.inFrameLikelihood ?: 0f) > 0.45f &&
                (rightWrist?.inFrameLikelihood ?: 0f) > 0.45f

        val isBodyDetected = leftArmVisible || rightArmVisible

        if (!isBodyDetected) {
            onResult(
                PushupPoseAnalysisResult(
                    repCount = repCount,
                    currentElbowAngle = 180.0,
                    isDownState = false,
                    isBodyDetected = false,
                    formFeedback = "Kameraga butun gavdangiz ko‘rinsin",
                    formAccuracyScore = 70,
                    landmarks = landmarksMap,
                    imageWidth = imageWidth,
                    imageHeight = imageHeight,
                    rotationDegrees = rotationDegrees
                )
            )
            return
        }

        // Calculate elbow angles
        var leftAngle = 180.0
        var rightAngle = 180.0
        if (leftArmVisible && leftShoulder != null && leftElbow != null && leftWrist != null) {
            leftAngle = calculateAngle(leftShoulder.position, leftElbow.position, leftWrist.position)
        }
        if (rightArmVisible && rightShoulder != null && rightElbow != null && rightWrist != null) {
            rightAngle = calculateAngle(rightShoulder.position, rightElbow.position, rightWrist.position)
        }

        val activeAngle = when {
            leftArmVisible && rightArmVisible -> (leftAngle + rightAngle) / 2.0
            leftArmVisible -> leftAngle
            else -> rightAngle
        }

        // Body straightness check (hip angle)
        var bodyStraight = true
        var hipAngle = 180.0
        val hipVisible = (leftHip?.inFrameLikelihood ?: 0f) > 0.45f || (rightHip?.inFrameLikelihood ?: 0f) > 0.45f
        if (hipVisible) {
            val s = if (leftArmVisible && leftShoulder != null) leftShoulder.position else rightShoulder?.position
            val h = if ((leftHip?.inFrameLikelihood ?: 0f) > 0.45f && leftHip != null) leftHip.position else rightHip?.position
            val knee = pose.getPoseLandmark(PoseLandmark.LEFT_KNEE)?.position ?: pose.getPoseLandmark(PoseLandmark.RIGHT_KNEE)?.position
            if (s != null && h != null && knee != null) {
                hipAngle = calculateAngle(s, h, knee)
                if (hipAngle < 135.0) {
                    bodyStraight = false
                }
            }
        }

        // Push-up counting state machine
        // UP: angle > 150°
        // DOWN: angle < 95°
        var repJustCompleted = false
        var feedback = "Tayyor. Harakatni boshlang!"
        var accuracy = 95

        if (activeAngle < lowestAngleRecorded) {
            lowestAngleRecorded = activeAngle
        }

        if (activeAngle <= 95.0) {
            isDown = true
            hasReachedLowestPoint = true
            feedback = if (bodyStraight) "A'lo chuqurlik! Endi ko‘tariling 💪" else "Gavdani tekis tuting!"
            accuracy = if (bodyStraight) 100 else 80
        } else if (activeAngle > 145.0) {
            if (isDown && hasReachedLowestPoint) {
                // Completed valid rep!
                repCount++
                repJustCompleted = true
                onRepCompleted(repCount)
                feedback = "A'lo! +1 Sanaldi 👏"
                accuracy = 100
                isDown = false
                hasReachedLowestPoint = false
                lowestAngleRecorded = 180.0
            } else if (hasReachedLowestPoint && lowestAngleRecorded > 105.0) {
                feedback = "Ko‘krakni pastroq tushiring (yarim harakat)!"
                accuracy = 65
                hasReachedLowestPoint = false
                lowestAngleRecorded = 180.0
            } else {
                feedback = if (bodyStraight) "Holat a'lo! Pastga tushing" else "Gavdani tekis tuting!"
                accuracy = if (bodyStraight) 95 else 75
            }
        } else {
            // In transit
            feedback = if (isDown) "Yuqoriga to‘liq ko‘tariling..." else "Pastroq tushing..."
            accuracy = 90
        }

        onResult(
            PushupPoseAnalysisResult(
                repCount = repCount,
                currentElbowAngle = activeAngle,
                isDownState = isDown,
                isBodyDetected = true,
                formFeedback = feedback,
                formAccuracyScore = accuracy,
                landmarks = landmarksMap,
                imageWidth = imageWidth,
                imageHeight = imageHeight,
                rotationDegrees = rotationDegrees,
                isRepJustCompleted = repJustCompleted
            )
        )
    }

    private fun calculateAngle(first: PointF, mid: PointF, last: PointF): Double {
        var angle = Math.toDegrees(
            atan2((last.y - mid.y).toDouble(), (last.x - mid.x).toDouble()) -
                    atan2((first.y - mid.y).toDouble(), (first.x - mid.x).toDouble())
        )
        angle = abs(angle)
        if (angle > 180.0) {
            angle = 360.0 - angle
        }
        return angle
    }
}
